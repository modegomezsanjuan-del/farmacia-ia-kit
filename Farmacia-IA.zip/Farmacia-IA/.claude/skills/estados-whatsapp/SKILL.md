---
name: estados-whatsapp
description: Estados de WhatsApp de la farmacia con los productos de parafarmacia sin rotación. 3 publicaciones por semana (presentación, consideración y conversión de un producto) con imagen de diseño propio, que se preparan solas cada semana y se publican solas en el Estado de WhatsApp. Usar para instalarlo y configurarlo, preparar una semana, hacer una oferta, revisar un aviso o medir lo vendido.
disable-model-invocation: true
---

# Estados de WhatsApp con los productos sin rotación

Versión 1.0-beta · 24/11/2026 · Copia del sistema que funciona en la farmacia del autor desde el 20/11/2026.

Sigue las reglas de `CLAUDE.md` en todo momento. Ejecuta los pasos en orden.

## Qué hace

- Cada semana se elige **un producto de parafarmacia sin rotación**: el de más valor parado (stock × PVP) que se pueda anunciar.
- Se preparan **3 imágenes** de 1080×1920 (el formato del Estado) con el diseño de la serie: **presentación** (qué es), **consideración** (resuelve una duda) y **conversión** (pasos para consultarlo en la farmacia).
- **Se publican solas** en el Estado de WhatsApp de la farmacia los días de publicación (por defecto lunes, miércoles y viernes a las 10:00). Lo hace un Edge invisible con WhatsApp Web y la sesión vinculada de la farmacia.
- **Se preparan solas**: cada lunes a las 12:30, Claude Code (sin ventana) prepara la siguiente semana pendiente, hasta 5 semanas vista.
- **Ofertas** (opcional, martes y jueves): solo las que pida la persona.
- Todo queda archivado en la **carpeta de archivo** (`Pendientes o sin confirmacion`, `Publicadas`, `Descartadas o retiradas` e `Indice.csv`). Ahí aparecen los avisos si algo falla.

El programa está en `estados-whatsapp/`:

| Archivo | Qué hace |
|---|---|
| `instalar.ps1` | Instala lo necesario (Node.js, Python y librerías) y prepara la carpeta de archivo. Con `-Tareas` crea las tareas programadas |
| `cola.py` | Dice qué semana toca preparar y qué productos son los siguientes. Solo lectura |
| `diseno/generar_piezas.py` | Genera las 3 imágenes de una ficha (`diseno/fichas/*.json`) y, con `--archivar`, las deja en `Pendientes` |
| `diseno/generar_oferta.py` | Lo mismo para las ofertas |
| `publicar.js` | Publica en el Estado la imagen de `Pendientes` con la fecha de hoy |
| `ejecutar.ps1` / `preparar.ps1` | Lo que lanzan las tareas programadas: publicar y preparar la semana |
| `vincular.js`, `Vincular WhatsApp.cmd` | Vincular WhatsApp (QR) |
| `borrar_estado.js` | Borrar un estado propio de hoy |
| `preparar_semana.md` | Las instrucciones que sigue Claude Code en la preparación automática |
| `bloqueos.json`, `festivos.txt` | Productos que se saltan y días en que no se publica |

## Qué necesita el ordenador

- Windows 10 u 11 con Microsoft Edge, internet y **Claude Code** (módulo 0).
- **Encendido y con la sesión de Windows abierta** a la hora de publicar y a la de preparar. Si está apagado, ese día no se publica y no se recupera más tarde.
- El móvil con el **WhatsApp de la farmacia** (mejor WhatsApp Business) para vincularlo una vez.
- Node.js y Python: los instala `instalar.ps1` si faltan.

---

## Paso 1 · Configuración

1. Lee `config/farmacia.json`. Si no existe, o le falta algo de la sección `estados_whatsapp`, pregunta **solo lo que falte**, de uno en uno, con el valor por defecto entre paréntesis:

   | Campo | Pregunta | Por defecto |
   |---|---|---|
   | `nombre_farmacia` (fuera de la sección) | ¿Cómo se llama la farmacia? | — (obligatorio) |
   | `cabecera` | ¿Cómo quieres que salga el nombre arriba de las imágenes, en dos líneas? | `["FARMACIA", "<NOMBRE>"]` |
   | `lema` | ¿Qué frase corta quieres en el pie, debajo del nombre? | `SALUD · CONFIANZA · CERCA DE TI` |
   | `carpeta_archivo` | ¿Dónde quieres la carpeta con las publicaciones y los avisos? | `<Escritorio>\Publicaciones WhatsApp` (la ruta real del Escritorio: `[Environment]::GetFolderPath('Desktop')`) |
   | `lista_sin_rotacion` | Ruta del Excel de parafarmacia sin rotación (Paso 3) | `<carpeta del kit>\exportaciones\parafarmacia-sin-rotacion.xlsx` |
   | `dias_publicacion` | ¿Qué 3 días publicamos? (presentación, consideración, conversión) | `["lunes", "miercoles", "viernes"]` |
   | `hora_publicacion` | ¿A qué hora? | `10:00` |
   | `dias_ofertas` | ¿Quieres dejar dos días para ofertas? | `["martes", "jueves"]` (o `[]`) |
   | `dia_preparacion`, `hora_preparacion` | ¿Cuándo preparo sola la semana? (el ordenador tiene que estar encendido) | `lunes`, `12:30` |
   | `exclusiones` | ¿Hay productos que no quieras anunciar nunca? (códigos) | `[]` |
   | `modelo_preparacion` | No se pregunta: el modelo de la preparación automática | `claude-opus-5-5` |
   | `zona_horaria` | No se pregunta salvo en Canarias (`Atlantic/Canary`) | `Europe/Madrid` |

2. Enséñale los valores y pide confirmación. Guárdalos sin borrar los campos que ya hubiera. Ejemplo:

   ```json
   {
     "nombre_farmacia": "Farmacia Ejemplo",
     "estados_whatsapp": {
       "cabecera": ["FARMACIA", "EJEMPLO"],
       "lema": "SALUD · CONFIANZA · CERCA DE TI",
       "carpeta_archivo": "C:\\Users\\Farmacia\\Desktop\\Publicaciones WhatsApp",
       "lista_sin_rotacion": "C:\\Users\\Farmacia\\Farmacia-IA\\exportaciones\\parafarmacia-sin-rotacion.xlsx",
       "dias_publicacion": ["lunes", "miercoles", "viernes"],
       "hora_publicacion": "10:00",
       "dias_ofertas": ["martes", "jueves"],
       "dia_preparacion": "lunes",
       "hora_preparacion": "12:30",
       "exclusiones": [],
       "modelo_preparacion": "claude-opus-5-5"
     }
   }
   ```

## Paso 2 · Instalar

1. Ejecuta: `powershell -NoProfile -ExecutionPolicy Bypass -File estados-whatsapp\instalar.ps1`
2. Tiene que terminar con `INSTALACION CORRECTA`. Si no, mira «Errores conocidos». Si no está ahí, **para** y enséñale el error a la persona.
3. Se instala antes de mirar la lista porque para leerla hace falta Python (lo detectó Claude Code en la primera prueba en un Windows limpio, el 25/11/2026).

## Paso 3 · La lista de parafarmacia sin rotación (Nixfarma)

1. Si la persona ya tiene el Excel en otra carpeta (por ejemplo, el Escritorio), **cópialo** (sin moverlo) a la ruta de `lista_sin_rotacion`.
2. Si el archivo de `lista_sin_rotacion` no existe, **para** y dale a la persona estas instrucciones:

   > Necesito el listado de **parafarmacia** sin rotación. En Nixfarma:
   > 1. Entra en **Almacén > Informes > Artículos sin movimiento**.
   > 2. En **Selección de artículos** indica **Stock actual >0** y, en **Clase** o **Tipo de producto**, solo **parafarmacia** (nada de medicamentos).
   > 3. Marca **Artículos sin movimiento**, elige **Ventas** y pon desde cuándo (por ejemplo, desde el 1 de enero o 6 meses atrás).
   > 4. Pulsa **Aceptar**. Con el listado en pantalla, pulsa **Exportar** (o **Ctrl+F10**), deja marcados al menos **Código, Descripción, Stock, P.V.P. y Caducidad**, y pulsa **Excel**.
   > 5. Guárdalo en `<ruta de lista_sin_rotacion>`.
   >
   > No uses «Imprimir > Visor > Fichero de datos»: ese archivo sale sin los nombres de las columnas.

3. Ejecuta `python -I estados-whatsapp/cola.py`.
   - Si dice que faltan columnas, repite el punto 2.
   - Enséñale a la persona los 10 candidatos (código, producto, stock, valor) y pregunta si alguno no se debe anunciar. Lo que diga va a `exclusiones`.
4. Si entre los candidatos aparece **cualquier medicamento**, **para**: la exportación no está filtrada. Repite el punto 2.
5. Recomiéndale actualizar la lista una vez al mes, guardándola con el mismo nombre. Con más de 30 días no pasa nada (las piezas nunca llevan precio ni stock), pero la cola se queda vieja.

## Paso 4 · Vincular WhatsApp

1. Explícale a la persona: «Se va a abrir una ventana de WhatsApp Web. En el móvil de la farmacia ve a WhatsApp > Ajustes (o ⋮) > Dispositivos vinculados > Vincular un dispositivo, y escanea el código QR de la pantalla».
2. Ejecuta `node vincular.js` dentro de `estados-whatsapp` y espera a que diga `VINCULADO`. Tienes 15 minutos.
3. Dile que la sesión queda guardada en `estados-whatsapp\perfil`. **Esa carpeta da acceso al WhatsApp de la farmacia: no se copia ni se comparte.** Si algún día cambia de ordenador, hay que quitar el dispositivo en el móvil.

## Paso 5 · Preparar la primera semana (con la persona delante)

1. Sigue los pasos 1 a 7 de `estados-whatsapp/preparar_semana.md`, pero **sin trabajar solo**: enséñale el producto elegido y las fuentes, y las 3 imágenes (ábrelas con Read).
2. Pregúntale si el estilo, los colores y los textos le parecen bien. Corrige lo que pida antes de archivar.
3. Si quiere que el diseño cambie para todas las semanas (por ejemplo, otro tono de colores), apúntalo en `config/farmacia.json` > `estados_whatsapp.notas_diseno`.

## Paso 6 · Ensayo sin publicar

1. Ejecuta en `estados-whatsapp`: `node publicar.js --ensayo --fecha <fecha de la primera imagen preparada>`
2. Tiene que decir `ENSAYO correcto: vista previa lista; NO se ha enviado`. Enséñale la captura `registros/<fecha>-vista-previa.png`: tiene que verse la imagen, el destino **Estado (Contactos)** y el botón de enviar.

## Paso 7 · Activar

1. Explícale, y **pide su confirmación expresa**:
   - Desde ahora, los días de publicación a la hora elegida, el ordenador publicará solo la imagen preparada para ese día, sin abrir ninguna ventana.
   - Cada semana, el día y la hora de preparación, Claude Code preparará sola la semana siguiente.
   - **Riesgo:** WhatsApp no permite oficialmente manejar WhatsApp Web con un programa. Con 3-5 estados por semana para los propios contactos el riesgo es bajo, pero existe: WhatsApp podría limitar el número. Nunca se usa para chats ni envíos masivos.
2. Con su sí: `powershell -NoProfile -ExecutionPolicy Bypass -File estados-whatsapp\instalar.ps1 -Tareas`
3. Comprueba que existen las tareas: `Get-ScheduledTask -TaskName 'Estados WhatsApp*'`.

---

## Lo que puede pedir la persona después

| Petición | Qué haces |
|---|---|
| «Prepara la semana que viene» | Los pasos de `preparar_semana.md`, enseñándole el resultado antes de archivar |
| «Haz una oferta para el martes» | Ficha `diseno/fichas/oferta-<nombre>.json` como `ejemplo-oferta.json`, con las fotos en `diseno/fotos/` y las **condiciones literales** del cartel o del laboratorio (pídeselas; no las inventes). Fecha: un día de `dias_ofertas`. `python -I diseno/generar_oferta.py <ficha>`, se la enseñas y después `--solo-html --archivar` |
| «Cambia el producto de la semana X» | Mueve su carpeta de `Pendientes o sin confirmacion` a `Descartadas o retiradas`, cambia el estado de sus filas en `Indice.csv` a «Descartadas o retiradas» (con su nueva ruta) y prepara otra vez |
| «Tal día no publiques» | Añade la fecha a `festivos.txt`. Ese día no se publica y no se pasa a otro día |
| «Borra el estado de hoy» | `node borrar_estado.js --hora HH:MM` (la hora a la que se publicó) |
| «¿Cuánto se ha vendido de lo publicado?» | Para cada producto de `Publicadas`, las ventas en Nixfarma desde la primera publicación: **Ventas > Diario de operaciones > Diario de ventas**, un código cada vez, desde esa fecha hasta hoy. Te pasa las cifras la persona, o un listado exportado. Resultado: tabla con producto, fecha, unidades y € a PVP, y el total |
| Hay un `_AVISO` en la carpeta de archivo | Léelo y mira la tabla de errores. `_AVISO estado WhatsApp.txt` = falló la publicación de hoy. `_AVISO preparar la semana.txt` = faltan imágenes para los próximos días |

**Nunca publiques a mano** salvo que la persona lo pida, y **nunca repitas** una publicación marcada como `incierto` en `registros/historial.json`: primero que mire «Mi estado» en el móvil.

## Reglas del contenido

1. **Solo parafarmacia sin rotación** de la lista. Nunca medicamentos (regla 3 de `CLAUDE.md`).
2. **Un producto por semana y tres fases distintas:**
   - Presentación: qué es y su fórmula o utilidad.
   - Consideración: resuelve **una** duda concreta.
   - Conversión: pasos o motivos para consultarlo en la farmacia.
3. **Solo afirmaciones de la ficha del fabricante o de farmacias online**, del producto exacto. Nada de adelgazar, quemar grasa, eliminar toxinas o curar. Ninguna cifra en la que las fuentes no coincidan.
4. **Sin precio ni stock** en las piezas («Consulta precio y disponibilidad»).
5. **El cierre invita a venir a la farmacia.** Nunca «escribe», «envía», «responde» ni «di una palabra clave».
6. **Diseño de la serie:**
   - Patrón `ortopedia` (burdeos) para ortopedia.
   - Patrón `cosmetica` (colores del envase) para todo lo demás.
   - Siempre 1080×1920. Nunca se añaden franjas ni se reescala otra imagen.
7. **Tallas o lados del mismo modelo = una sola campaña.** Las otras tallas van a `bloqueos.json`.
8. Si no hay ficha o foto exacta del producto, va a `bloqueos.json` con el motivo, y se pasa al siguiente.

## Resumen final

Al terminar la instalación:
```
✅ Estados de WhatsApp activados
Publica: <días> a las <hora> · Prepara: <día> a las <hora> · Ofertas: <días o "no">
Carpeta de archivo: <ruta>
Semanas preparadas: <fechas de la primera y la última imagen en Pendientes>
Ensayo: correcto (<fecha>)
Si aparece un aviso en la carpeta de archivo, abre Claude Code y escribe /estados-whatsapp.
```

Al preparar una semana:
```
✅ Semana del <lunes> preparada: <producto> (<código>)
<fecha> presentación · <fecha> consideración · <fecha> conversión
Fuentes: <urls>
Bloqueados: <códigos y motivo, o "ninguno">
```

## Errores conocidos

| Síntoma | Causa | Solución |
|---|---|---|
| Aviso «WhatsApp Web no tiene la sesión abierta» (código 3) | El móvil ha quitado el dispositivo vinculado o la sesión ha caducado | Paso 4 otra vez (`Vincular WhatsApp`, también en la carpeta de archivo) |
| Aviso «La vista previa no muestra el destino Estado (Contactos)» | Tras varios días sin abrir WhatsApp Web, la lista de contactos tarda en cargar (visto el 23/11/2026) | `publicar.js` ya espera 30 s. Si se repite, `node publicar.js --ensayo --visible` para que cargue y avisa a la persona: ese día no se publicó |
| Aviso de código 4 «no se pudo confirmar» | Se pulsó enviar pero no apareció la confirmación | **No reintentar.** Que la persona mire «Mi estado» en el móvil |
| `cola.py`: «no tiene las columnas Código, Descripción, Stock y PVP» | Exportado desde el visor (cabeceras `TextNN`) | Exportar con **Exportar / Ctrl+F10** a Excel (Paso 3) |
| La preparación automática termina con error de modelo o de créditos | El modelo de `modelo_preparacion` no está disponible en su plan para `claude -p` | Cambiar `modelo_preparacion` por uno que sí tenga |
| `Indice.csv` con filas en blanco o repetidas | Se editó con un programa que cambia los saltos de línea | Los programas lo escriben bien. No lo abras ni lo guardes con Excel |
| La imagen se ve pequeña en el Estado | No es 1080×1920 | Generar siempre con `generar_piezas.py`. Nunca reescalar |
| Al activar (Paso 7) el instalador vuelve a descargar Node o Python | La ventana de Claude Code se abrió antes de instalarlos y no tenía la ruta (PATH) al día | El instalador ya actualiza la ruta al empezar (versión del 25/11/2026). Con una versión anterior: para, actualiza la ruta y crea solo las tareas |
| `generar_piezas.py` o `cola.py`: «No module named PIL / openpyxl» | Librerías instaladas con `--user` y Python lanzado con `-I` (versión anterior del kit) | Volver a ejecutar `instalar.ps1`: ahora las pone en `estados-whatsapp\lib` |
| No se publicó un día | El ordenador estaba apagado o con la sesión de Windows cerrada a esa hora | No se recupera sola. Si la persona lo pide ese mismo día: `powershell -File estados-whatsapp\ejecutar.ps1` |
