// Abre WhatsApp Web en un perfil propio de Edge para vincular la cuenta de la farmacia (QR).
// La sesión queda guardada en .\perfil y la reutiliza publicar.js.
const { chromium } = require('playwright-core');
const path = require('path');
const fs = require('fs');

const { config } = require('./comun');
const PERFIL = config().perfil;
const LOGS = path.join(__dirname, 'registros');
fs.mkdirSync(LOGS, { recursive: true });

(async () => {
  const ctx = await chromium.launchPersistentContext(PERFIL, {
    channel: 'msedge', headless: false, viewport: { width: 1280, height: 860 },
    args: ['--window-position=80,40'], locale: 'es-ES',
  });
  const page = ctx.pages()[0] || await ctx.newPage();
  await page.goto('https://web.whatsapp.com/', { waitUntil: 'domcontentloaded' });
  console.log('Esperando a que se vincule (en el móvil de la farmacia: WhatsApp > Dispositivos vinculados > Vincular un dispositivo, y escanea el QR)...');
  const limite = Date.now() + 15 * 60 * 1000;
  let ok = false;
  while (Date.now() < limite) {
    const dentro = await page.locator('#pane-side, [aria-label="Lista de chats"], [aria-label="Chat list"]').first().isVisible().catch(() => false);
    if (dentro) { ok = true; break; }
    await page.waitForTimeout(2000);
  }
  await page.screenshot({ path: path.join(LOGS, 'vinculacion.png') });
  console.log(ok ? 'VINCULADO' : 'NO VINCULADO (tiempo agotado)');
  await page.waitForTimeout(8000);   // deja terminar la sincronización inicial
  await ctx.close();
})().catch(e => { console.error('ERROR', e.message); process.exit(1); });
