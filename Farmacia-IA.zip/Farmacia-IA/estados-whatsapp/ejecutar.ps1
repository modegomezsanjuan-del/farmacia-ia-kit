﻿# Lanzador para el Programador de tareas: publica el estado previsto para hoy (si hay imagen con la fecha de hoy).
# Si algo falla, deja un aviso en la carpeta de publicaciones.
# Además avisa si los próximos días de publicación no tienen imagen preparada.
param([string]$Imagen = '')
$base = $PSScriptRoot
$kit = Split-Path $base
$conf = Get-Content (Join-Path $kit 'config\farmacia.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$cfg = $conf.estados_whatsapp
$carpeta = $cfg.carpeta_archivo
$logs = Join-Path $base 'registros'
New-Item -ItemType Directory -Path $logs -Force | Out-Null
$log = Join-Path $logs ("ejecucion-" + (Get-Date -Format 'yyyy-MM-dd_HHmm') + '.log')
$aviso = Join-Path $carpeta '_AVISO estado WhatsApp.txt'
$avisoSemana = Join-Path $carpeta '_AVISO preparar la semana.txt'
$node = (Get-Command node -ErrorAction SilentlyContinue).Source
if (-not $node) { $node = 'C:\Program Files\nodejs\node.exe' }

Set-Location $base
"=== Inicio $(Get-Date) ===" | Out-File $log -Encoding utf8
$argumentos = @('publicar.js')
if ($Imagen) { $argumentos += @('--imagen', $Imagen) }
& $node @argumentos 2>&1 | ForEach-Object { "$_" } | Out-File -FilePath $log -Append -Encoding utf8
$code = $LASTEXITCODE
"=== Fin $(Get-Date) codigo $code ===" | Out-File $log -Append -Encoding utf8

$motivos = @{
  1 = 'Error durante la publicacion (ver captura *-error.png en la carpeta registros).';
  2 = 'Ya habia un registro de hoy (publicado, enviando o incierto): no se ha vuelto a publicar.';
  3 = 'WhatsApp Web no tiene la sesion abierta: hay que volver a vincular (doble clic en "Vincular WhatsApp.cmd" y escanear el QR).';
  4 = 'Se pulso Enviar pero no se pudo confirmar. NO se reintenta: revisa Mi estado en el movil.';
  5 = 'No habia ninguna imagen preparada para hoy en "Pendientes o sin confirmacion".'
}
if ($code -ne 0) {
  $m = $motivos[[int]$code]; if (-not $m) { $m = "Codigo $code." }
  @("Estado de WhatsApp del $(Get-Date -Format 'dd/MM/yyyy HH:mm'):", $m, "Detalle: $log") | Out-File $aviso -Encoding utf8
} elseif (Test-Path $aviso) {
  Remove-Item $aviso
}

# Comprobar las 3 proximas fechas de publicacion que no sean festivo
function SinAcentos([string]$s) { ($s.ToLower().Normalize([Text.NormalizationForm]::FormD) -replace '\p{Mn}', '') }
$mapa = @{ lunes = 'Monday'; martes = 'Tuesday'; miercoles = 'Wednesday'; jueves = 'Thursday'; viernes = 'Friday'; sabado = 'Saturday'; domingo = 'Sunday' }
$dias = @('lunes', 'miercoles', 'viernes'); if ($cfg.dias_publicacion) { $dias = @($cfg.dias_publicacion) }
$diasEn = $dias | ForEach-Object { $mapa[(SinAcentos $_)] }
$pend = Join-Path $carpeta 'Pendientes o sin confirmacion'
$festivos = @()
if (Test-Path (Join-Path $base 'festivos.txt')) { $festivos = Get-Content (Join-Path $base 'festivos.txt') -Encoding UTF8 | Where-Object { $_ -match '^\d{4}-\d{2}-\d{2}' } | ForEach-Object { $_.Substring(0,10) } }
$faltan = @()
$d = (Get-Date).Date.AddDays(1); $n = 0
while ($n -lt 3) {
  if (($diasEn -contains $d.DayOfWeek.ToString()) -and ($festivos -notcontains $d.ToString('yyyy-MM-dd'))) {
    $f = $d.ToString('yyyy-MM-dd')
    $hay = Get-ChildItem -Path $pend -Recurse -File -Filter "$f - *.png" -ErrorAction SilentlyContinue
    if (-not $hay) { $faltan += $d.ToString('dddd dd/MM', [Globalization.CultureInfo]'es-ES') }
    $n++
  }
  $d = $d.AddDays(1)
}
if ($faltan.Count -gt 0) {
  @("Faltan publicaciones preparadas para: " + ($faltan -join ', ') + '.',
    'Abre Claude Code en la carpeta Farmacia-IA y pide: "prepara los estados de WhatsApp de la semana que viene".') | Out-File $avisoSemana -Encoding utf8
} elseif (Test-Path $avisoSemana) {
  Remove-Item $avisoSemana
}
exit $code
