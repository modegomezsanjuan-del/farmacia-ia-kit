﻿# Instala lo necesario para los estados de WhatsApp en este ordenador.
#   .\instalar.ps1           -> comprueba e instala Edge/Node/Python/librerias, crea la carpeta de archivo y el acceso directo
#   .\instalar.ps1 -Tareas   -> ademas crea (o actualiza) las dos tareas programadas: publicar y preparar la semana
# Requiere config\farmacia.json con la seccion "estados_whatsapp" (la crea Claude Code con la persona).
param([switch]$Tareas)
$ErrorActionPreference = 'Stop'
$base = $PSScriptRoot
$kit = Split-Path $base
function Paso([string]$m) { Write-Host "-> $m" }
function Refresca-Path { $env:Path = [Environment]::GetEnvironmentVariable('Path', 'Machine') + ';' + [Environment]::GetEnvironmentVariable('Path', 'User') }

# 1) Configuracion
$cfgFile = Join-Path $kit 'config\farmacia.json'
if (-not (Test-Path $cfgFile)) { throw "Falta $cfgFile. Configura primero los estados de WhatsApp con Claude Code." }
$conf = Get-Content $cfgFile -Raw -Encoding UTF8 | ConvertFrom-Json
$cfg = $conf.estados_whatsapp
if (-not $cfg -or -not $cfg.carpeta_archivo -or -not $cfg.lista_sin_rotacion) { throw 'Faltan carpeta_archivo o lista_sin_rotacion en config\farmacia.json.' }
Paso "Configuracion de $($conf.nombre_farmacia): correcta"

# 2) Microsoft Edge (viene con Windows)
$edge = @("${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe", "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe") | Where-Object { Test-Path $_ } | Select-Object -First 1
if (-not $edge) { throw 'No encuentro Microsoft Edge. Instalalo desde https://www.microsoft.com/edge y vuelve a ejecutar.' }
Paso "Edge: $edge"

# Sin winget (Windows antiguos o recien instalados) se descargan los instaladores oficiales
$hayWinget = [bool](Get-Command winget -ErrorAction SilentlyContinue)
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
function Descarga([string]$url) {
  $f = Join-Path $env:TEMP (Split-Path $url -Leaf)
  Paso "Descargando $url"
  Invoke-WebRequest $url -OutFile $f -UseBasicParsing
  return $f
}

# 3) Node.js
if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
  if ($hayWinget) {
    Paso 'Instalando Node.js (winget)...'
    winget install --id OpenJS.NodeJS.LTS -e --silent --accept-package-agreements --accept-source-agreements | Out-Host
  } else {
    $versiones = Invoke-RestMethod 'https://nodejs.org/dist/index.json' -UseBasicParsing   # en PowerShell 5.1 llega como un solo objeto:
    $lts = ($versiones | ForEach-Object { $_ } | Where-Object { $_.lts } | Select-Object -First 1).version   # se separa antes de filtrar
    $msi = Descarga "https://nodejs.org/dist/$lts/node-$lts-x64.msi"
    Paso "Instalando Node.js $lts (Windows pedira permiso: pulsa Si)..."
    Start-Process msiexec.exe -ArgumentList "/i `"$msi`" /qn /norestart" -Verb RunAs -Wait
  }
  Refresca-Path
  if (-not (Get-Command node -ErrorAction SilentlyContinue)) { throw 'No se pudo instalar Node.js. Cierra y abre la ventana y vuelve a probar.' }
}
Paso "Node.js: $(node --version)"

# 4) Python (ojo: el "python" de la Microsoft Store es solo un acceso a la tienda)
function Busca-Python {
  foreach ($c in @('py', 'python')) {
    $cmd = Get-Command $c -ErrorAction SilentlyContinue
    if (-not $cmd -or $cmd.Source -like '*WindowsApps*') { continue }
    try { $v = & $c -c "import sys; print(sys.version_info[:2] >= (3, 10))" 2>$null; if ($v -eq 'True') { return $c } } catch {}
  }
  return $null
}
$py = Busca-Python
if (-not $py) {
  $opciones = '/quiet InstallAllUsers=0 PrependPath=1 Include_launcher=1 InstallLauncherAllUsers=0'
  if ($hayWinget) {
    Paso 'Instalando Python 3.12 (winget)...'
    winget install --id Python.Python.3.12 -e --silent --accept-package-agreements --accept-source-agreements --override $opciones | Out-Host
  } else {
    $exe = Descarga 'https://www.python.org/ftp/python/3.12.10/python-3.12.10-amd64.exe'
    Paso 'Instalando Python 3.12...'
    Start-Process $exe -ArgumentList $opciones -Wait
  }
  Refresca-Path
  $py = Busca-Python
  if (-not $py) { throw 'No se pudo instalar Python. Cierra y abre la ventana y vuelve a probar.' }
}
Paso "Python: $(& $py --version)"
Paso 'Librerias de Python (pillow, numpy, openpyxl)...'
& $py -m pip install --user --quiet --disable-pip-version-check pillow numpy openpyxl | Out-Host

# 5) Programa de publicacion (playwright-core usa el Edge del equipo: no descarga navegadores)
Paso 'Instalando el programa de publicacion (npm)...'
Push-Location $base
try { npm install --no-audit --no-fund --loglevel=error | Out-Host } finally { Pop-Location }

# 6) Carpeta de archivo de publicaciones
$carpeta = $cfg.carpeta_archivo
foreach ($sub in @('Pendientes o sin confirmacion', 'Publicadas', 'Descartadas o retiradas')) {
  New-Item -ItemType Directory -Force -Path (Join-Path $carpeta $sub) | Out-Null
}
New-Item -ItemType Directory -Force -Path (Join-Path $base 'diseno\fotos'), (Join-Path $base 'registros') | Out-Null
$indice = Join-Path $carpeta 'Indice.csv'
if (-not (Test-Path $indice)) {
  [IO.File]::WriteAllText($indice, "fecha;producto;estado;archivo;origen;sha256`r`n", (New-Object Text.UTF8Encoding $true))
}
Paso "Carpeta de archivo: $carpeta"

# 7) Acceso directo para volver a vincular WhatsApp, junto a los avisos (en la carpeta de archivo)
$lnk = Join-Path $carpeta 'Vincular WhatsApp.lnk'
$sh = New-Object -ComObject WScript.Shell
$a = $sh.CreateShortcut($lnk); $a.TargetPath = Join-Path $base 'Vincular WhatsApp.cmd'; $a.WorkingDirectory = $base; $a.Save()
Paso "Acceso directo 'Vincular WhatsApp' en la carpeta de archivo"

# 8) Comprobacion: los programas leen la configuracion
Push-Location $base
try {
  node -e "const c = require('./comun').config(); console.log('Publicacion: dias', c.dias_publicacion.join(','), '| ofertas', c.dias_ofertas.join(','), '|', c.zona_horaria)" | Out-Host
  & $py -I -c "import sys; sys.path.insert(0, r'$base'); import comun; c = comun.config(); print('Preparacion: lista', c['lista_sin_rotacion'].name, '| existe:', c['lista_sin_rotacion'].exists())" | Out-Host
} finally { Pop-Location }

# 9) Tareas programadas (solo con -Tareas)
if ($Tareas) {
  function SinAcentos([string]$s) { ($s.ToLower().Normalize([Text.NormalizationForm]::FormD) -replace '\p{Mn}', '') }
  $mapa = @{ lunes = 'Monday'; martes = 'Tuesday'; miercoles = 'Wednesday'; jueves = 'Thursday'; viernes = 'Friday'; sabado = 'Saturday'; domingo = 'Sunday' }
  $pub = @('lunes', 'miercoles', 'viernes'); if ($cfg.dias_publicacion) { $pub = @($cfg.dias_publicacion) }
  $ofe = @('martes', 'jueves'); if ($null -ne $cfg.dias_ofertas) { $ofe = @($cfg.dias_ofertas) }
  $dias = @($pub + $ofe | ForEach-Object { $mapa[(SinAcentos $_)] } | Select-Object -Unique)
  $hora = if ($cfg.hora_publicacion) { $cfg.hora_publicacion } else { '10:00' }
  $horaPrep = if ($cfg.hora_preparacion) { $cfg.hora_preparacion } else { '12:30' }
  $diaPrep = if ($cfg.dia_preparacion) { $mapa[(SinAcentos $cfg.dia_preparacion)] } else { 'Monday' }
  $yo = "$env:USERDOMAIN\$env:USERNAME"
  $quien = New-ScheduledTaskPrincipal -UserId $yo -LogonType Interactive -RunLevel Limited

  $acc = New-ScheduledTaskAction -Execute 'powershell.exe' -Argument "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$base\ejecutar.ps1`"" -WorkingDirectory $base
  $disp = New-ScheduledTaskTrigger -Weekly -DaysOfWeek $dias -At $hora
  $aj = New-ScheduledTaskSettingsSet -ExecutionTimeLimit (New-TimeSpan -Minutes 20) -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries
  Register-ScheduledTask -TaskName 'Estados WhatsApp - publicar' -Action $acc -Trigger $disp -Principal $quien -Settings $aj -Force | Out-Null
  Paso "Tarea 'Estados WhatsApp - publicar': $($dias -join ', ') a las $hora"

  $acc2 = New-ScheduledTaskAction -Execute 'powershell.exe' -Argument "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$base\preparar.ps1`"" -WorkingDirectory $base
  $disp2 = New-ScheduledTaskTrigger -Weekly -DaysOfWeek $diaPrep -At $horaPrep
  $aj2 = New-ScheduledTaskSettingsSet -ExecutionTimeLimit (New-TimeSpan -Minutes 90) -StartWhenAvailable -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries
  Register-ScheduledTask -TaskName 'Estados WhatsApp - preparar semana' -Action $acc2 -Trigger $disp2 -Principal $quien -Settings $aj2 -Force | Out-Null
  Paso "Tarea 'Estados WhatsApp - preparar semana': $diaPrep a las $horaPrep"
}
Write-Host 'INSTALACION CORRECTA' -ForegroundColor Green
