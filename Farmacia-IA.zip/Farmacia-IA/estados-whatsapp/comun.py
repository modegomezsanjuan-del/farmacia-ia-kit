"""Configuración común de los estados de WhatsApp. Lee ../config/farmacia.json (sección "estados_whatsapp")."""
import json
from pathlib import Path

BASE = Path(__file__).resolve().parent
KIT = BASE.parent
DIAS = {"lunes": 0, "martes": 1, "miercoles": 2, "miércoles": 2, "jueves": 3, "viernes": 4,
        "sabado": 5, "sábado": 5, "domingo": 6}   # como date.weekday(): 0 = lunes
FASES = ("presentacion", "consideracion", "conversion")


def config():
    ruta = KIT / "config" / "farmacia.json"
    if not ruta.exists():
        raise SystemExit(f"Falta {ruta}. Configura primero la automatización con Claude Code.")
    c = json.loads(ruta.read_text(encoding="utf-8-sig"))
    e = c.get("estados_whatsapp", {})
    for campo in ("carpeta_archivo", "lista_sin_rotacion"):
        if not e.get(campo):
            raise SystemExit(f'Falta "estados_whatsapp.{campo}" en config/farmacia.json.')
    nombre = c.get("nombre_farmacia", "")
    cab = e.get("cabecera") or ["FARMACIA", nombre.upper().replace("FARMACIA", "").strip()]
    dias = [DIAS[d.lower()] for d in e.get("dias_publicacion", ["lunes", "miercoles", "viernes"])]
    if len(dias) != 3:
        raise SystemExit("dias_publicacion tiene que tener 3 días (presentación, consideración y conversión).")
    return {
        "nombre_farmacia": nombre,
        "cabecera": cab,                                   # 2 líneas: ["FARMACIA", "GÓMEZ SANJUÁN"]
        "firma": e.get("firma") or " ".join(cab).upper(),  # nombre en el pie
        "lema": e.get("lema", "SALUD · CONFIANZA · CERCA DE TI"),
        "carpeta_archivo": Path(e["carpeta_archivo"]),
        "lista_sin_rotacion": Path(e["lista_sin_rotacion"]),
        "dias_publicacion": sorted(dias),
        "semanas_vista": int(e.get("semanas_vista", 5)),
        "dias_caducidad_minimos": int(e.get("dias_caducidad_minimos", 30)),
        "exclusiones": {str(x.get("codigo") if isinstance(x, dict) else x) for x in e.get("exclusiones", [])},
    }


def carpeta_edge():
    for d in (r"C:\Program Files (x86)\Microsoft\Edge\Application", r"C:\Program Files\Microsoft\Edge\Application"):
        if (Path(d) / "msedge.exe").exists():
            return Path(d) / "msedge.exe"
    raise SystemExit("No encuentro Microsoft Edge (msedge.exe).")
