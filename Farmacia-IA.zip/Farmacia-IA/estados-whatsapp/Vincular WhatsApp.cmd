@echo off
rem Abre WhatsApp Web para vincular la cuenta de la farmacia (escanear el QR con el movil).
cd /d "%~dp0"
node vincular.js
pause
