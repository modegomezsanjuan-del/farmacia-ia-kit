// Borra estados propios publicados en WhatsApp ("Mi estado").
// Uso: node borrar_estado.js --explorar   -> abre el visor de Mi estado y guarda capturas/botones
//      node borrar_estado.js --hora 13:27 -> borra el estado propio publicado a esa hora (de hoy)
const { chromium } = require('playwright-core');
const path = require('path');
const fs = require('fs');
const { config, agenteEdge } = require('./comun');
const CFG = config();
const BASE = __dirname, PERFIL = CFG.perfil, LOGS = path.join(BASE, 'registros');
fs.mkdirSync(LOGS, { recursive: true });
const args = process.argv.slice(2);
const EXPLORAR = args.includes('--explorar');
const i = args.indexOf('--hora'); const HORA = i >= 0 ? args[i + 1] : null;
const ahora = () => new Date().toLocaleString('sv-SE', { timeZone: CFG.zona_horaria });
const log = (m) => { const l = `[${ahora()}] ${m}`; console.log(l); fs.appendFileSync(path.join(LOGS, 'registro.log'), l + '\n'); };

async function volcar(page, nombre) {
  const info = await page.evaluate(() => {
    const out = [];
    document.querySelectorAll('button,[role=button],[role=menuitem],[role=dialog] *,[aria-label],[title],[data-icon]').forEach(e => {
      const r = e.getBoundingClientRect(); if (r.width === 0) return;
      const t = (e.innerText || '').slice(0, 40).replace(/\n/g, ' ');
      out.push([e.tagName, e.getAttribute('role'), e.getAttribute('aria-label'), e.getAttribute('title'), e.getAttribute('data-icon'), t, Math.round(r.x), Math.round(r.y)].join(' | '));
    });
    return [...new Set(out)];
  });
  fs.writeFileSync(path.join(LOGS, nombre + '.txt'), info.join('\n'), 'utf8');
  await page.screenshot({ path: path.join(LOGS, nombre + '.png') });
}

(async () => {
  const ctx = await chromium.launchPersistentContext(PERFIL, {
    channel: 'msedge', headless: !args.includes('--visible'), viewport: { width: 1280, height: 860 }, locale: 'es-ES',
    userAgent: agenteEdge(),
  });
  const page = ctx.pages()[0] || await ctx.newPage();
  try {
    await page.goto('https://web.whatsapp.com/', { waitUntil: 'domcontentloaded', timeout: 60000 });
    await page.locator('#pane-side').first().waitFor({ timeout: 90000 });
    await page.waitForTimeout(2500);
    await page.locator('[aria-label="Estados"]').first().click();
    await page.waitForTimeout(2000);
    await page.locator('button:has-text("Mi estado")').first().click();
    await page.waitForTimeout(3000);
    if (EXPLORAR) {
      await volcar(page, 'borrar-1-visor');
      // pausar y abrir el menú del visor para ver sus opciones
      const menu = page.locator('[aria-label="Menú"], [aria-label="Más opciones"], [aria-label="Menu"], [data-icon="menu"], [data-icon*="more"]').last();
      if (await menu.isVisible().catch(() => false)) { await menu.click(); await page.waitForTimeout(1200); await volcar(page, 'borrar-2-menu'); }
      log('Exploración de borrado guardada.');
    } else {
      if (!HORA) throw new Error('Falta --hora HH:MM');
      const cab = await page.locator(`text=Hoy a la(s) ${HORA}`).first().isVisible().catch(() => false);
      if (!cab) { await volcar(page, 'borrar-sin-hora'); throw new Error(`El visor no muestra un estado propio de hoy a las ${HORA}; no se borra nada`); }
      await page.locator('button[aria-label="Pausar"]').first().click({ force: true }).catch(() => {});
      await page.waitForTimeout(600);
      await page.locator('button[aria-label="Menú"]:not([disabled])').last().click({ force: true });
      await page.waitForTimeout(1000);
      const op = page.locator('[role=menuitem]:has-text("Eliminar"), li:has-text("Eliminar"), [role=button]:has-text("Eliminar")').first();
      await op.waitFor({ timeout: 8000 });
      await op.click({ force: true });
      await page.waitForTimeout(1000);
      await volcar(page, 'borrar-3-confirmar');
      const conf = page.locator('[role=dialog] button:has-text("Eliminar"), [data-animate-modal-popup] button:has-text("Eliminar"), button:has-text("Eliminar")').last();
      await conf.waitFor({ timeout: 8000 });
      await conf.click({ force: true });
      await page.waitForTimeout(4000);
      // volver a la lista de Estados para comprobar de verdad
      await page.goto('https://web.whatsapp.com/', { waitUntil: 'domcontentloaded' });
      await page.locator('#pane-side').first().waitFor({ timeout: 90000 });
      await page.waitForTimeout(2000);
      await page.locator('[aria-label="Estados"]').first().click();
      await page.waitForTimeout(2500);
      const fila = await page.locator('button:has-text("Mi estado")').first().innerText().catch(() => '');
      await page.screenshot({ path: path.join(LOGS, `borrado-${HORA.replace(':', '')}-evidencia.png`) });
      if (fila.includes(HORA)) throw new Error('Tras eliminar, Mi estado sigue mostrando ' + HORA);
      log(`BORRADO el estado propio de hoy a las ${HORA}. Mi estado ahora: ${fila.replace(/\n/g, ' ')}`);
    }
  } catch (e) {
    await page.screenshot({ path: path.join(LOGS, 'borrar-error.png') }).catch(() => {});
    log('ERROR borrar: ' + e.message);
    process.exitCode = 1;
  }
  await ctx.close();
})();
