// Configuración común de los estados de WhatsApp. Lee ../config/farmacia.json (sección "estados_whatsapp").
const path = require('path');
const fs = require('fs');

const BASE = __dirname;
const KIT = path.resolve(BASE, '..');
const DIAS = { domingo: 0, lunes: 1, martes: 2, miercoles: 3, 'miércoles': 3, jueves: 4, viernes: 5, sabado: 6, 'sábado': 6 };

function config() {
  const ruta = path.join(KIT, 'config', 'farmacia.json');
  if (!fs.existsSync(ruta)) throw new Error(`Falta ${ruta}. Configura primero la automatización con Claude Code.`);
  const c = JSON.parse(fs.readFileSync(ruta, 'utf8').replace(/^\uFEFF/, ''));
  const e = c.estados_whatsapp || {};
  if (!e.carpeta_archivo) throw new Error('Falta "estados_whatsapp.carpeta_archivo" en config/farmacia.json.');
  const dias = (lista, defecto) => (lista || defecto).map(d => DIAS[String(d).toLowerCase()]).filter(n => n !== undefined);
  return {
    nombre_farmacia: c.nombre_farmacia || '',
    carpeta_archivo: e.carpeta_archivo,
    perfil: e.perfil || path.join(BASE, 'perfil'),
    zona_horaria: e.zona_horaria || 'Europe/Madrid',
    dias_publicacion: dias(e.dias_publicacion, ['lunes', 'miercoles', 'viernes']),   // 0 = domingo
    dias_ofertas: dias(e.dias_ofertas, ['martes', 'jueves']),
  };
}

// Carpeta de Edge (en unos equipos está en Program Files (x86) y en otros en Program Files)
function carpetaEdge() {
  for (const d of ['C:\\Program Files (x86)\\Microsoft\\Edge\\Application', 'C:\\Program Files\\Microsoft\\Edge\\Application']) {
    if (fs.existsSync(path.join(d, 'msedge.exe'))) return d;
  }
  return null;
}

// Agente de usuario normal de Edge, para que WhatsApp Web acepte el navegador invisible
function agenteEdge() {
  const dir = carpetaEdge();
  let ver = '142.0.0.0';
  if (dir) {
    const v = fs.readdirSync(dir).filter(d => /^\d+\.\d+\.\d+\.\d+$/.test(d)).sort((a, b) => b.localeCompare(a, undefined, { numeric: true }))[0];
    if (v) ver = v;
  }
  return `Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${ver} Safari/537.36 Edg/${ver}`;
}

module.exports = { BASE, KIT, config, carpetaEdge, agenteEdge };
