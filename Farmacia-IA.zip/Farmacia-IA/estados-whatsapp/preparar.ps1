﻿# Lanzador semanal: Claude Code (sin ventana) prepara la siguiente semana de estados de WhatsApp. No publica.
# -Prueba: solo comprueba que encuentra Claude Code y la configuracion, sin lanzar nada.
param([switch]$Prueba)
$base = $PSScriptRoot
$kit = Split-Path $base
$conf = Get-Content (Join-Path $kit 'config\farmacia.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$cfg = $conf.estados_whatsapp
$carpeta = $cfg.carpeta_archivo
$modelo = if ($cfg.modelo_preparacion) { $cfg.modelo_preparacion } else { 'claude-opus-5-5' }
$logs = Join-Path $base 'registros'
New-Item -ItemType Directory -Path $logs -Force | Out-Null
$log = Join-Path $logs ("preparacion-" + (Get-Date -Format 'yyyy-MM-dd_HHmm') + '.log')
$aviso = Join-Path $carpeta '_AVISO preparar la semana.txt'

# Claude Code: el del PATH (instalador oficial) o el que trae la extension de VS Code (la version mas reciente)
$claude = (Get-Command claude -ErrorAction SilentlyContinue).Source
if (-not $claude -and (Test-Path "$env:USERPROFILE\.local\bin\claude.exe")) { $claude = "$env:USERPROFILE\.local\bin\claude.exe" }
if (-not $claude) {
  $ext = Get-ChildItem "$env:USERPROFILE\.vscode\extensions" -Directory -Filter 'anthropic.claude-code-*' -ErrorAction SilentlyContinue |
         Sort-Object LastWriteTime -Descending | Select-Object -First 1
  if ($ext) { $claude = Join-Path $ext.FullName 'resources\native-binary\claude.exe' }
}
if (-not $claude -or -not (Test-Path $claude)) {
  "Preparacion automatica $(Get-Date -Format 'dd/MM/yyyy HH:mm'): no se encuentra Claude Code en este ordenador." | Out-File $aviso -Encoding utf8
  exit 1
}

$prompt = (Get-Content (Join-Path $base 'preparar_semana.md') -Raw -Encoding UTF8).Replace('{NOMBRE_FARMACIA}', $conf.nombre_farmacia).Replace('{CARPETA_ARCHIVO}', $carpeta)
if ($Prueba) {
  "Claude Code: $claude"; "Modelo: $modelo"; "Carpeta de archivo: $carpeta"
  "Instrucciones: $($prompt.Length) caracteres; empiezan asi:"; $prompt.Substring(0, [Math]::Min(200, $prompt.Length))
  exit 0
}

Set-Location $base
"=== Inicio $(Get-Date) con $claude ($modelo) ===" | Out-File $log -Encoding utf8
$prompt | & $claude -p --model $modelo `
  --allowedTools "Bash,PowerShell,Read,Write,Edit,Glob,Grep,WebSearch,WebFetch" `
  --add-dir $carpeta `
  --max-turns 200 --output-format text 2>&1 | ForEach-Object { "$_" } | Out-File -FilePath $log -Append -Encoding utf8
$code = $LASTEXITCODE
"=== Fin $(Get-Date) codigo $code ===" | Out-File $log -Append -Encoding utf8
if ($code -ne 0 -and -not (Test-Path $aviso)) {
  "Preparacion automatica $(Get-Date -Format 'dd/MM/yyyy HH:mm'): Claude termino con error ($code). Detalle: $log" | Out-File $aviso -Encoding utf8
}
exit $code
