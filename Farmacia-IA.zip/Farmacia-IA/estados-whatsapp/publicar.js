// Publica en el Estado de WhatsApp de la farmacia la imagen prevista para hoy.
// Uso:
//   node publicar.js                     -> busca en "Pendientes o sin confirmacion" la imagen con la fecha de hoy y la publica
//   node publicar.js --fecha 2026-11-23  -> idem para otra fecha (solo pruebas)
//   node publicar.js --imagen RUTA.png   -> publica esa imagen concreta
//   node publicar.js --ensayo            -> llega hasta la vista previa SIN enviar
//   node publicar.js --explorar          -> solo abre Estados y guarda capturas y botones (para ajustar)
// Reglas: nunca publica dos veces la misma fecha; si un envío queda dudoso no se repite.
const { chromium } = require('playwright-core');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');

const { BASE, config, agenteEdge } = require('./comun');
const CFG = config();
const LOGS = path.join(BASE, 'registros');
const HIST = path.join(LOGS, 'historial.json');
const ARCH = CFG.carpeta_archivo;
fs.mkdirSync(LOGS, { recursive: true });

const args = process.argv.slice(2);
const opt = (n) => { const i = args.indexOf(n); return i >= 0 ? (args[i + 1] || true) : null; };
const ENSAYO = args.includes('--ensayo');
const EXPLORAR = args.includes('--explorar');
const PERFIL = (opt('--perfil') && opt('--perfil') !== true) ? path.resolve(opt('--perfil')) : CFG.perfil;
const hoyMadrid = () => new Intl.DateTimeFormat('sv-SE', { timeZone: CFG.zona_horaria }).format(new Date());
const FECHA = opt('--fecha') || hoyMadrid();
const ahora = () => new Date().toLocaleString('sv-SE', { timeZone: CFG.zona_horaria });
const log = (m) => { const l = `[${ahora()}] ${m}`; console.log(l); fs.appendFileSync(path.join(LOGS, 'registro.log'), l + '\n'); };

function leerHist() { try { return JSON.parse(fs.readFileSync(HIST, 'utf8')); } catch { return []; } }
function guardarHist(h) { fs.writeFileSync(HIST, JSON.stringify(h, null, 2), 'utf8'); }
function marcar(entrada) {
  const h = leerHist();
  const i = h.findIndex(e => e.id === entrada.id);
  if (i >= 0) h[i] = { ...h[i], ...entrada }; else h.push(entrada);
  guardarHist(h);
}
const sha256 = (p) => crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');

function buscarImagen() {
  const im = opt('--imagen');
  if (im && im !== true) return path.resolve(im);
  const pend = path.join(ARCH, 'Pendientes o sin confirmacion');
  const encontradas = [];
  for (const d of fs.readdirSync(pend, { withFileTypes: true })) {
    if (!d.isDirectory()) continue;
    for (const f of fs.readdirSync(path.join(pend, d.name))) {
      if (f.startsWith(FECHA + ' - ') && f.toLowerCase().endsWith('.png')) encontradas.push(path.join(pend, d.name, f));
    }
  }
  if (encontradas.length !== 1) throw new Error(`Se esperaba 1 imagen pendiente con fecha ${FECHA} y hay ${encontradas.length}: ${encontradas.join(' | ')}`);
  return encontradas[0];
}

// Tras publicar: mover la copia a Publicadas y actualizar Indice.csv
function archivarPublicada(img) {
  const pend = path.join(ARCH, 'Pendientes o sin confirmacion');
  if (!img.startsWith(pend)) return 'imagen fuera del archivo; sin mover';
  const relViejo = path.relative(ARCH, img);
  const destino = path.join(ARCH, 'Publicadas', path.relative(pend, img));
  fs.mkdirSync(path.dirname(destino), { recursive: true });
  if (fs.existsSync(destino)) return 'ya existía en Publicadas; sin mover';
  fs.renameSync(img, destino);
  if (sha256(destino) === '') return 'error';
  const relNuevo = path.relative(ARCH, destino);
  const idx = path.join(ARCH, 'Indice.csv');
  let txt = fs.readFileSync(idx, 'utf8');
  const bom = txt.charCodeAt(0) === 0xfeff; if (bom) txt = txt.slice(1);
  const lineas = txt.split('\r\n').map(l => {
    const c = l.split(';');
    if (c.length >= 6 && c[3] === relViejo) { c[2] = 'Publicadas'; c[3] = relNuevo; return c.join(';'); }
    return l;
  });
  fs.writeFileSync(idx, (bom ? '\ufeff' : '') + lineas.join('\r\n'), 'utf8');
  // quitar carpeta de pendientes si queda vacía
  try { const dir = path.dirname(img); if (fs.readdirSync(dir).length === 0) fs.rmdirSync(dir); } catch {}
  return 'movida a ' + relNuevo;
}

async function primeroVisible(page, selectores, ms = 15000) {
  const fin = Date.now() + ms;
  while (Date.now() < fin) {
    for (const s of selectores) {
      const l = page.locator(s).first();
      if (await l.isVisible().catch(() => false)) return l;
    }
    await page.waitForTimeout(400);
  }
  return null;
}

async function volcarBotones(page, nombre) {
  const info = await page.evaluate(() => {
    const out = [];
    document.querySelectorAll('button,[role=button],[role=menuitem],[role=tab],[aria-label],[title],[data-icon],input[type=file]').forEach(e => {
      const r = e.getBoundingClientRect();
      if (r.width === 0 && e.tagName !== 'INPUT') return;
      out.push([e.tagName, e.getAttribute('role'), e.getAttribute('aria-label'), e.getAttribute('title'), e.getAttribute('data-icon'), e.getAttribute('accept'), (e.innerText || '').slice(0, 40).replace(/\n/g, ' '), Math.round(r.x), Math.round(r.y)].join(' | '));
    });
    return out;
  });
  fs.writeFileSync(path.join(LOGS, nombre + '.txt'), info.join('\n'), 'utf8');
  await page.screenshot({ path: path.join(LOGS, nombre + '.png') });
}

(async () => {
  let img = null, id = null;
  if (!EXPLORAR) {
    const festivos = (() => { try { return fs.readFileSync(path.join(BASE, 'festivos.txt'), 'utf8').split(/\r?\n/).map(l => l.trim().slice(0, 10)).filter(l => /^\d{4}-\d{2}-\d{2}$/.test(l)); } catch { return []; } })();
    const diaSemana = new Date(FECHA + 'T12:00:00').getDay();          // 0 domingo ... 6 sábado
    const diaDePublicacion = CFG.dias_publicacion.includes(diaSemana) && !festivos.includes(FECHA);
    if (festivos.includes(FECHA) && !opt('--imagen')) { log(`Festivo (${FECHA}): no se publica.`); process.exit(0); }
    try { img = buscarImagen(); } catch (e) {
      if (/y hay 0/.test(e.message) && !diaDePublicacion) { log(`Sin imagen para ${FECHA} (no es día de publicación): nada que hacer.`); process.exit(0); }
      log('SIN IMAGEN: ' + e.message); process.exit(5);
    }
    id = `${FECHA}|${path.basename(img)}|${ahora()}`;
    const previas = leerHist().filter(e => e.fecha === FECHA && ['publicado', 'enviando', 'incierto'].includes(e.estado));
    if (previas.length && !ENSAYO) {
      log(`NO SE PUBLICA: ya hay un registro de ${FECHA} en estado ${previas.map(p => p.estado).join(',')} (${previas[0].archivo}).`);
      process.exit(2);
    }
    log(`Imagen: ${img} (sha256 ${sha256(img).slice(0, 16)}…) ${ENSAYO ? '[ENSAYO, sin enviar]' : ''}`);
  }

  // Navegador invisible (sin ventana). Se usa el agente de usuario normal de Edge para que WhatsApp Web lo acepte.
  const VISIBLE = args.includes('--visible');
  const UA = agenteEdge();
  const ctx = await chromium.launchPersistentContext(PERFIL, {
    channel: 'msedge', headless: !VISIBLE, viewport: { width: 1280, height: 860 }, locale: 'es-ES',
    userAgent: UA, args: VISIBLE ? ['--window-position=80,40'] : [],
  });
  const page = ctx.pages()[0] || await ctx.newPage();
  const cerrar = async (code) => { await page.waitForTimeout(1500); await ctx.close(); process.exit(code); };
  try {
    await page.goto('https://web.whatsapp.com/', { waitUntil: 'domcontentloaded', timeout: 60000 });
    const dentro = await primeroVisible(page, ['#pane-side', '[aria-label="Lista de chats"]', '[aria-label="Chat list"]'], 90000);
    if (!dentro) {
      const qr = await page.locator('canvas').first().isVisible().catch(() => false);
      await page.screenshot({ path: path.join(LOGS, `${FECHA}-sin-sesion.png`) });
      log(qr ? 'SESIÓN CADUCADA: WhatsApp pide escanear el QR (doble clic en «Vincular WhatsApp.cmd»).' : 'WhatsApp Web no cargó la lista de chats.');
      if (id) marcar({ id, fecha: FECHA, archivo: img, estado: 'fallo', motivo: qr ? 'sesion_caducada' : 'no_carga', hora: ahora() });
      return cerrar(3);
    }
    await page.waitForTimeout(3000);

    // 1) Abrir Estados
    const btnEstados = await primeroVisible(page, ['[aria-label="Estados"]', '[aria-label="Status"]', 'button[title="Estados"]', '[data-icon*="status"]'], 15000);
    if (!btnEstados) throw new Error('No encuentro el botón Estados');
    await btnEstados.click();
    await page.waitForTimeout(2500);
    if (EXPLORAR) { await volcarBotones(page, 'explorar-estados'); log('Exploración guardada.'); return cerrar(0); }

    // 2) Añadir estado -> Fotos y vídeos
    const btnAnadir = await primeroVisible(page, ['[aria-label="Añadir estado"]', '[aria-label="Agregar estado"]', '[aria-label="Add Status"]', '[aria-label="Add status"]', '[title="Añadir estado"]', '[data-icon="status-add"]', '[data-icon*="add"]'], 15000);
    if (!btnAnadir) { await volcarBotones(page, `${FECHA}-sin-boton-anadir`); throw new Error('No encuentro «Añadir estado»'); }
    await btnAnadir.click();
    await page.waitForTimeout(1200);
    const opFotos = await primeroVisible(page, ['[role=menuitem]:has-text("Fotos")', 'li:has-text("Fotos y vídeos")', 'text=Fotos y vídeos', '[role=menuitem]:has-text("Photos")', 'text=Photos & videos'], 8000);
    if (!opFotos) { await volcarBotones(page, `${FECHA}-sin-menu-fotos`); throw new Error('No encuentro «Fotos y vídeos»'); }
    const [chooser] = await Promise.all([page.waitForEvent('filechooser', { timeout: 10000 }), opFotos.click()]);
    await chooser.setFiles(img);

    // 3) Vista previa y botón Enviar
    const btnEnviar = await primeroVisible(page, ['[role=button][aria-label^="Enviar"]', '[aria-label="Enviar"]', '[role=button][aria-label^="Send"]', '[data-icon="send"]', '[data-icon="wds-ic-send-filled"]', 'span[data-icon*="send"]'], 30000);
    // El público («Estado (Contactos)») tarda en cargar si WhatsApp lleva días sin abrirse (23/11: a las 10:00 solo ponía «Estado»).
    const destino = !!(await primeroVisible(page, ['button:has-text("Estado (Contactos)")', 'button:has-text("Estado (")'], 30000));
    if (!destino) { await volcarBotones(page, `${FECHA}-sin-destino`); throw new Error('La vista previa no muestra el destino «Estado (Contactos)»'); }
    if (!btnEnviar) { await volcarBotones(page, `${FECHA}-sin-enviar`); throw new Error('No aparece el botón Enviar en la vista previa'); }
    await page.waitForTimeout(1500);
    await page.screenshot({ path: path.join(LOGS, `${FECHA}-vista-previa.png`) });
    if (ENSAYO) { log('ENSAYO correcto: vista previa lista; NO se ha enviado.'); return cerrar(0); }

    marcar({ id, fecha: FECHA, archivo: img, sha256: sha256(img), estado: 'enviando', hora: ahora() });
    await btnEnviar.click();
    log('Pulsado Enviar; comprobando que aparece en Mi estado…');

    // 4) Comprobación: la vista previa desaparece y "Mi estado" muestra una actualización reciente
    // Confirmación estricta: aviso "Se compartió el estado" o "Mi estado" con la hora de hoy (±3 min del envío)
    const envioMin = (() => { const d = new Date(new Date().toLocaleString('en-US', { timeZone: CFG.zona_horaria })); return d.getHours() * 60 + d.getMinutes(); })();
    let confirmado = false, prueba = '';
    const fin = Date.now() + 90000;
    while (Date.now() < fin) {
      const previaAbierta = await btnEnviar.isVisible().catch(() => false);
      if (!previaAbierta) {
        const aviso = await page.locator('text=/Se compartió el estado|Status shared/i').first().isVisible().catch(() => false);
        if (aviso) { confirmado = true; prueba = 'aviso «Se compartió el estado»'; break; }
        const fila = await page.locator('button:has-text("Mi estado")').first().innerText().catch(() => '');
        const m = fila.match(/Hoy a la\(s\) (\d{1,2}):(\d{2})/);
        if (m && Math.abs(Number(m[1]) * 60 + Number(m[2]) - envioMin) <= 3) { confirmado = true; prueba = 'Mi estado ' + m[0]; break; }
      }
      await page.waitForTimeout(1000);
    }
    await page.waitForTimeout(4000);
    await page.screenshot({ path: path.join(LOGS, `${FECHA}-evidencia.png`) });
    if (confirmado) {
      const mov = archivarPublicada(img);
      marcar({ id, estado: 'publicado', confirmado: ahora(), prueba, evidencia: path.join(LOGS, `${FECHA}-evidencia.png`), archivo_final: mov });
      log(`PUBLICADO (${prueba}). Archivo: ${mov}`);
      return cerrar(0);
    }
    marcar({ id, estado: 'incierto', hora_fin: ahora() });
    log('INCIERTO: se pulsó Enviar pero no se pudo confirmar. NO se reintentará; revisar Mi estado en el móvil.');
    return cerrar(4);
  } catch (e) {
    await page.screenshot({ path: path.join(LOGS, `${FECHA}-error.png`) }).catch(() => {});
    log('ERROR: ' + e.message);
    if (id && !ENSAYO) { const h = leerHist().find(x => x.id === id); if (!h || h.estado !== 'enviando') marcar({ id, fecha: FECHA, archivo: img, estado: 'fallo', motivo: e.message, hora: ahora() }); else marcar({ id, estado: 'incierto', motivo: e.message }); }
    return cerrar(1);
  }
})();
