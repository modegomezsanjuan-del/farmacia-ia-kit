"""Qué semana toca preparar y qué productos de la lista de PARAFARMACIA SIN ROTACIÓN son los siguientes.
Solo lectura. Uso: python -I cola.py [--hoy AAAA-MM-DD]
Salida JSON: semana_a_preparar (lunes y las 3 fechas con su fase) y hasta 10 candidatos ordenados por valor (stock × PVP).

La lista es un Excel o CSV exportado de Nixfarma (ruta en config/farmacia.json > estados_whatsapp.lista_sin_rotacion)
con, al menos, las columnas Código, Descripción, Stock y PVP (Caducidad es opcional).
Se excluyen: lo ya preparado o publicado (Indice.csv), bloqueos.json, las exclusiones de la configuración,
los productos sin stock o sin PVP, los que caducan en menos de dias_caducidad_minimos y las otras tallas
de un modelo ya usado.
"""
# Librerías de Python del kit (pillow, numpy, openpyxl) en estados-whatsapp/lib: así funcionan también con "python -I"
import sys as _s, pathlib as _p
_lib = _p.Path(__file__).resolve().parents[0] / "lib"
if _lib.exists(): _s.path.insert(0, str(_lib))
import csv, json, re, sys, unicodedata
import datetime as dt
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import comun  # noqa: E402

sys.stdout.reconfigure(encoding="utf-8")   # Windows usa cp1252 al redirigir la salida
CFG = comun.config()
BASE = comun.BASE
ARCH = CFG["carpeta_archivo"]

hoy = dt.date.today()
if "--hoy" in sys.argv:
    hoy = dt.date.fromisoformat(sys.argv[sys.argv.index("--hoy") + 1])


def norm(x):
    return "".join(c for c in unicodedata.normalize("NFKD", str(x or "")) if c.isalnum() and not unicodedata.combining(c)).lower()


def numero(v):
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v or "").strip().replace("€", "").replace(" ", "")
    if not s:
        return None
    if "," in s:
        s = s.replace(".", "").replace(",", ".")
    try:
        return float(s)
    except ValueError:
        return None


def fecha(v):
    if isinstance(v, dt.datetime):
        return v.date()
    if isinstance(v, dt.date):
        return v
    s = str(v or "").strip()
    for fmt in ("%d/%m/%Y", "%d/%m/%y", "%Y-%m-%d", "%m/%Y", "%m/%y"):
        try:
            return dt.datetime.strptime(s[:10], fmt).date()
        except ValueError:
            pass
    return None


# ---------- 1) lista de Nixfarma ----------
CLAVES = {"codigo": ("codigo", "cn", "codigonacional", "articulo"), "descripcion": ("descripcion", "nombre", "producto"),
          "stock": ("stock", "stockactual", "existencias"), "pvp": ("pvp", "pvpeuros", "preciovp", "precio"),
          "caducidad": ("caducidad", "fechacaducidad")}


def filas_lista(ruta):
    if ruta.suffix.lower() in (".xlsx", ".xlsm"):
        import openpyxl
        libro = openpyxl.load_workbook(ruta, read_only=True, data_only=True)
        for hoja in libro:
            yield from ([*r] for r in hoja.iter_rows(values_only=True))
            yield None   # separador de hojas
        libro.close()
    else:
        datos = ruta.read_bytes()
        texto = datos.decode("utf-8-sig") if datos[:3] == b"\xef\xbb\xbf" else datos.decode("cp1252", errors="replace")
        sep = ";" if texto.count(";") > texto.count(",") else ","
        yield from csv.reader(texto.splitlines(), delimiter=sep)


def leer_lista(ruta):
    if not ruta.exists():
        raise SystemExit(f"No encuentro la lista de parafarmacia sin rotación: {ruta}")
    productos, idx, fila = [], None, 0
    for r in filas_lista(ruta):
        fila += 1
        if r is None:
            if productos:
                break
            idx = None
            continue
        if idx is None:   # buscar la fila de cabecera (Nixfarma pone a veces títulos encima)
            cab = [norm(v) for v in r]
            pos = {k: next((i for i, h in enumerate(cab) if h in alias), None) for k, alias in CLAVES.items()}
            if all(pos[k] is not None for k in ("codigo", "descripcion", "stock", "pvp")):
                idx = pos
            continue
        cod = r[idx["codigo"]] if idx["codigo"] < len(r) else None
        if cod in (None, ""):
            continue
        cod = str(int(cod)) if isinstance(cod, (int, float)) else str(cod).strip().lstrip("0") or "0"
        if not cod.isdigit():   # filas de totales o subtítulos
            continue
        val = lambda k: r[idx[k]] if idx[k] is not None and idx[k] < len(r) else None
        productos.append({"codigo": cod, "producto": str(val("descripcion") or "").strip(),
                          "stock": numero(val("stock")), "pvp": numero(val("pvp")),
                          "caducidad": fecha(val("caducidad")), "fila": fila})
    if idx is None:
        raise SystemExit(f"La lista {ruta.name} no tiene las columnas Código, Descripción, Stock y PVP.")
    return productos


# ---------- 2) semana a preparar ----------
festivos = set()
fest = BASE / "festivos.txt"
if fest.exists():
    for l in fest.read_text(encoding="utf-8").splitlines():
        if l[:4].isdigit():
            festivos.add(dt.date.fromisoformat(l[:10]))

idx_csv = ARCH / "Indice.csv"
indice = idx_csv.read_text(encoding="utf-8-sig").splitlines() if idx_csv.exists() else []
fechas_con_imagen = {l.split(";")[0] for l in indice[1:] if ";Pendientes o sin confirmacion;" in l or ";Publicadas;" in l}
codigos_usados = {l.split(";")[1].rsplit(" - ", 1)[-1].strip() for l in indice[1:] if l.count(";") >= 5}

lunes = hoy + dt.timedelta(days=(7 - hoy.weekday()) % 7 or 7)
semana = None
for k in range(CFG["semanas_vista"] + 1):
    L = lunes + dt.timedelta(weeks=k)
    plan = []
    for dia, fase in zip(CFG["dias_publicacion"], comun.FASES):
        f = L + dt.timedelta(days=dia)
        if f not in festivos:   # nunca se cambia de día: si es un cierre, ese día no hay pieza
            plan.append({"fase": fase, "fecha": f.isoformat()})
    if any(p["fecha"] not in fechas_con_imagen for p in plan):
        semana = {"lunes": L.isoformat(), "piezas": plan}
        break

# ---------- 3) candidatos ----------
ruta = CFG["lista_sin_rotacion"]
lista = leer_lista(ruta)
dias_lista = (hoy - dt.date.fromtimestamp(ruta.stat().st_mtime)).days
bloq_f = BASE / "bloqueos.json"
bloqueados = {str(b["codigo"]) for b in json.loads(bloq_f.read_text(encoding="utf-8"))["bloqueos"]} if bloq_f.exists() else set()


def modelo(desc):
    """Nombre sin talla ni lado: las tallas del mismo modelo son una sola campaña."""
    d = str(desc).lower()
    d = re.sub(r"\btalla\s+\S+|\bt\.\s*\S+", " ", d)
    d = re.sub(r"\b(peque(ña|ño)|peq|mediana|mediano|med|grande|gde|extragrande|izquierd[ao]|izq|derech[ao]|dcha|xs|xl|xxl|s|m|l)\b\.?", " ", d)
    return norm(d)


por_modelo = {}
for p in lista:
    por_modelo.setdefault(modelo(p["producto"]), set()).add(p["codigo"])
usados = set(codigos_usados)
for cods in por_modelo.values():
    if usados & cods:
        usados |= cods

dia_ref = dt.date.fromisoformat(semana["lunes"]) if semana else hoy
vistos, candidatos = set(), []
for p in sorted(lista, key=lambda p: (-(p["stock"] or 0) * (p["pvp"] or 0), p["fila"])):
    c = p["codigo"]
    if c in usados or c in bloqueados or c in CFG["exclusiones"] or c in vistos:
        continue
    if not p["stock"] or p["stock"] <= 0 or not p["pvp"] or p["pvp"] <= 0:
        continue
    if p["caducidad"] and (p["caducidad"] - dia_ref).days < CFG["dias_caducidad_minimos"]:
        continue
    vistos.add(c)
    otras = sorted(por_modelo[modelo(p["producto"])] - {c})
    candidatos.append({"codigo": c, "producto": p["producto"], "stock_segun_lista": p["stock"], "pvp_unitario": p["pvp"],
                       "valor_pvp": round(p["stock"] * p["pvp"], 2), "caducidad": p["caducidad"].isoformat() if p["caducidad"] else None,
                       "otras_tallas": otras})
    if len(candidatos) >= 10:
        break

print(json.dumps({
    "hoy": hoy.isoformat(),
    "semana_a_preparar": semana,
    "lista": {"archivo": str(ruta), "dias_desde_exportacion": dias_lista,
              "aviso": "Lista de más de 30 días: no pongas precio ni stock en las piezas." if dias_lista > 30 else ""},
    "nota": "Ordenados por stock × PVP. Ya excluidos: preparados/publicados (Indice.csv), bloqueos.json, exclusiones de la configuración, "
            "sin stock o PVP, caducidad cercana y otras tallas de modelos ya usados.",
    "candidatos": candidatos,
}, ensure_ascii=False, indent=2))
