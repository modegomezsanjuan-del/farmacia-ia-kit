"""Piezas de OFERTAS (1080x1920) para los estados de martes y jueves, con el patrón «cosmetica» de la carpeta.
uso: generar_oferta.py ficha_oferta.json [--solo-html] [--archivar]
  - Cada pieza lleva su fecha, 1 o 2 fotos de producto (fondo blanco) que se juntan en una sola escena,
    y una línea de condiciones de la promoción en el pie.
  - --archivar: copia a "Pendientes o sin confirmacion" de la carpeta de archivo y añade las filas de Indice.csv.
"""
# Librerías de Python del kit (pillow, numpy, openpyxl) en estados-whatsapp/lib: así funcionan también con "python -I"
import sys as _s, pathlib as _p
_lib = _p.Path(__file__).resolve().parents[1] / "lib"
if _lib.exists(): _s.path.insert(0, str(_lib))
import hashlib, json, shutil, subprocess, sys
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw

AQUI = Path(__file__).resolve().parent
sys.path.insert(0, str(AQUI))
import generar_piezas as G  # noqa: E402

G.I["regalo"] = ('<rect x="10" y="26" width="44" height="30" rx="3"/><rect x="6" y="18" width="52" height="10" rx="2"/>'
                 '<path d="M32 18v38"/><path d="M32 18c-4-10-16-12-16-4 0 4 8 4 16 4zM32 18c4-10 16-12 16-4 0 4-8 4-16 4z"/>')

FUENTE_BF = '<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@800;900&display=block" rel="stylesheet">'

CSS_OFERTA = G.CSS_COSM + """
.dispo { background:var(--d); }
.etiqueta { background:var(--chip); }
/* bloque de campaña, como el cartel del lineal: rojo / negro / rojo */
.bf { width:282px; font-family:"Montserrat",sans-serif; text-align:center; color:#fff; border-radius:10px; overflow:hidden;
      box-shadow:0 16px 34px rgba(0,0,0,.28); border:4px solid #fff; }
.bf .r1 { background:#e2393a; font-weight:900; font-size:36px; letter-spacing:.5px; padding:16px 0 12px; line-height:1; }
.bf .r2 { background:#141414; display:flex; align-items:center; justify-content:center; gap:8px; padding:14px 0 10px; overflow:hidden; }
.bf .r2 b { font-weight:900; font-size:90px; line-height:.9; letter-spacing:-4px; }
.bf .r2 span { font-weight:900; font-size:30px; line-height:.95; text-align:left; }
.bf .r3 { background:#e2393a; font-weight:900; font-size:37px; letter-spacing:1px; padding:12px 0 14px; line-height:1; }
.sello { width:236px; height:236px; border-radius:50%; background:var(--a); transform:rotate(-8deg); box-shadow:0 12px 26px rgba(0,0,0,.18);
         display:flex; align-items:center; justify-content:center; }
.sello > div { width:212px; height:212px; border-radius:50%; border:2px dashed rgba(255,255,255,.8); display:flex; flex-direction:column;
         align-items:center; justify-content:center; gap:4px; color:#fff; text-align:center; }
.sello span { font-family:"Source Serif 4",serif; font-weight:800; font-size:34px; line-height:1.02; letter-spacing:-.5px; }
.legal { font-family:"Source Sans 3",sans-serif; font-size:19px; line-height:1.35; color:#fff; white-space:nowrap; opacity:.95; }
"""


def recorte(ruta):
    """Producto sobre blanco -> RGBA recortado (fondo quitado por relleno desde el borde)."""
    im = Image.open(ruta).convert("RGB")
    a = np.asarray(im).astype(int)
    # casi blanco y sin color: incluye la sombra suave gris que traen algunas fotos de tienda
    blanco = (a.min(axis=2) > 222) & ((a.max(axis=2) - a.min(axis=2)) < 18)
    m = Image.fromarray(np.where(blanco, 255, 0).astype(np.uint8))
    w, h = m.size
    bordes = [(x, 0) for x in range(0, w, 8)] + [(x, h - 1) for x in range(0, w, 8)] + \
             [(0, y) for y in range(0, h, 8)] + [(w - 1, y) for y in range(0, h, 8)]
    for p in bordes:
        if m.getpixel(p) == 255:
            ImageDraw.floodfill(m, p, 128)
    fondo = np.asarray(m) == 128
    alfa = Image.fromarray(np.where(fondo, 0, 255).astype(np.uint8))
    rgba = im.convert("RGBA"); rgba.putalpha(alfa)
    return rgba.crop(alfa.getbbox())


def componer(fotos, salida):
    """Junta 1 o 2 productos: el segundo detrás, a la derecha y algo más pequeño. Sale sobre blanco."""
    if len(fotos) == 1:
        shutil.copy2(fotos[0], salida); return
    a, b = recorte(fotos[0]), recorte(fotos[1])
    hb = int(a.height * 0.9); b = b.resize((int(b.width * hb / b.height), hb), Image.LANCZOS)
    solape = int(b.width * 0.22)              # el de delante tapa solo un poco el de detrás
    W = a.width + b.width - solape + 40
    H = a.height + 90
    lienzo = Image.new("RGBA", (W, H), (255, 255, 255, 255))
    lienzo.alpha_composite(b, (20 + a.width - solape, H - hb - 20 - 70))   # detrás: apoya 70 px más arriba
    lienzo.alpha_composite(a, (20, H - a.height - 20))
    lienzo.convert("RGB").save(salida, quality=95)


def pieza_html(f, pz, fondo):
    c = {**f["colores"], **pz.get("colores", {})}
    f = {**f, "colores": c}          # los colores de cada pieza (los de sus packs) mandan
    p = c["principal"]
    h = G.cabecera(p) + G.cosm_etiqueta(pz)
    h += f'<div class="abs t fit" style="top:262px;font-size:{pz.get("t1_px", 112)}px;color:{p};">{G.e(pz["t1"])}</div>'
    h += f'<div class="abs t fit" style="top:384px;font-size:{pz.get("t2_px", 96)}px;letter-spacing:-1.5px;color:{c["acento"]};">{G.e(pz["t2"])}</div>'
    h += f'<div class="abs sub fit" style="top:492px;">{G.e(pz["sub"])}</div>'
    h += f'<div class="abs c manus fit" style="top:545px;font-size:64px;">{G.e(pz["manus"])}</div>' + G.trazo(620, 440, p)
    s = pz.get("sello")
    if s:
        h += (f'<div class="abs sello" style="left:{s.get("left", 150)}px;top:{s.get("top", 730)}px;">'
              f'<div>{G.svg("regalo", "#fff", 46, 3.2)}<span>{G.e(s["texto"])}</span></div></div>')
    b = pz.get("bf")
    if b:
        h += (f'<div class="abs bf" style="left:{b.get("left", 70)}px;top:{b.get("top", 660)}px;transform:rotate({b.get("rot", -4)}deg);">'
              f'<div class="r1">BLACK FRIDAY</div><div class="r2"><b>−20</b><span>%<br>DTO*</span></div>'
              f'<div class="r3">ANTIEDAD</div></div>')
    h += G.cosm_filas(f, pz["filas"], 680, 500) + G.cosm_dispo(pz) + G.cosm_manus_derecha(f, pz) + G.cosm_banda(f, pz)
    h += (f'<div class="abs pie" style="top:1740px;height:180px;"><div class="legal">{G.e(f["condiciones"])}</div>'
          f'<div class="firma"><div class="n">{G.e(G.CFG["firma"])}</div><div class="l">{G.e(G.CFG["lema"])}</div></div></div>')
    vars_ = (f':root{{--p:{p};--a:{c["acento"]};--pie:{c.get("pie", p)};--t:{c.get("tarjeta", "rgba(255,250,248,.93)")};'
             f'--tb:{c.get("borde", "rgba(0,0,0,.12)")};--sep:{c.get("separador", "rgba(0,0,0,.22)")};'
             f'--d:{c.get("dispo", c["acento"])};--chip:{c.get("chip", p)};}}')
    return (f'<!doctype html><html lang="es"><head><meta charset="utf-8"><title>{G.e(f["nombre_archivo"])} {pz["id"]}</title>{G.FUENTES}{FUENTE_BF}'
            f'<style>{vars_}{CSS_OFERTA.replace("FONDO", fondo)}</style></head><body><div class="lienzo">{h}</div>{G.AJUSTE_JS}</body></html>')


def main():
    f = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
    carpeta = AQUI / f["carpeta"]; carpeta.mkdir(parents=True, exist_ok=True)
    for pz in f["piezas"]:
        fondo = carpeta / f'fondo_{pz["id"]}.png'
        if "--solo-html" not in sys.argv or not fondo.exists():
            junta = carpeta / f'productos_{pz["id"]}.jpg'
            componer([str(G.ruta_foto(p)) for p in pz["fotos"]], junta)
            e = pz["escena"]
            cmd = [sys.executable, "-I", str(AQUI / "escena_packshot.py"), str(junta), str(fondo),
                   "--alto", str(e["alto"]), "--cx", str(e["cx"]), "--base", str(e["base"])]
            if e.get("horizonte"): cmd += ["--horizonte", str(e["horizonte"])]
            if e.get("max_ancho"): cmd += ["--max-ancho", str(e["max_ancho"])]
            subprocess.run(cmd, check=True, capture_output=True)
        hp = carpeta / f'{pz["id"]}.html'
        hp.write_text(pieza_html(f, pz, fondo.name), encoding="utf-8")
        G.render(hp, carpeta / f'{pz["id"]}.png')
        print("ok", pz["id"])
    if "--archivar" in sys.argv:
        archivar(f, carpeta)


def archivar(f, carpeta):
    nombre = f["nombre_archivo"]
    destino = G.ARCH / "Pendientes o sin confirmacion" / nombre
    destino.mkdir(parents=True, exist_ok=True)
    idx = G.ARCH / "Indice.csv"
    previo = idx.read_bytes().decode("utf-8-sig") if idx.exists() else "fecha;producto;estado;archivo;origen;sha256"
    txt = "\r\n".join(l for l in previo.splitlines() if l.strip())
    for pz in f["piezas"]:
        src = carpeta / f'{pz["id"]}.png'
        copia = destino / f'{pz["fecha"]} - {nombre} - {pz["id"]}.png'
        shutil.copy2(src, copia)
        h = hashlib.sha256(copia.read_bytes()).hexdigest()
        rel = str(copia.relative_to(G.ARCH))
        lineas = [l for l in txt.split("\r\n") if l.split(";")[3:4] != [rel]]
        lineas.append(f'{pz["fecha"]};{nombre};Pendientes o sin confirmacion;{rel};{src};{h}')
        txt = "\r\n".join(lineas)
        print("archivada", rel)
    idx.write_bytes(("﻿" + txt + "\r\n").encode("utf-8"))


if __name__ == "__main__":
    main()
