"""Escena 1080x1920 para una foto de producto con fondo blanco (packshot de tienda).
Recorta el producto (relleno desde el borde sobre el blanco), lo coloca sobre una encimera de mármol
con pared cálida, sombra de contacto y las hojas desenfocadas de la serie.

uso: escena_packshot.py foto salida.png --alto 650 --cx 540 --base 1240 [--horizonte 1080]
  --alto       altura del producto en el póster (px)
  --cx         centro horizontal del producto
  --base       línea donde apoya el producto
  --horizonte  donde empieza la encimera (por defecto base - 150)
"""
# Librerías de Python del kit (pillow, numpy, openpyxl) en estados-whatsapp/lib: así funcionan también con "python -I"
import sys as _s, pathlib as _p
_lib = _p.Path(__file__).resolve().parents[1] / "lib"
if _lib.exists(): _s.path.insert(0, str(_lib))
import argparse
from pathlib import Path
import numpy as np
from PIL import Image, ImageFilter

AQUI = Path(__file__).resolve().parent
W, H = 1080, 1920
ap = argparse.ArgumentParser()
ap.add_argument("foto"); ap.add_argument("salida")
ap.add_argument("--alto", type=float, required=True)
ap.add_argument("--cx", type=float, required=True)
ap.add_argument("--base", type=float, required=True)
ap.add_argument("--horizonte", type=float, default=None)
ap.add_argument("--max-ancho", type=float, default=900)
ap.add_argument("--cortar-abajo", type=int, default=None, help="fila de la foto original donde acaba el producto (quita reflejos)")
a = ap.parse_args()
hz = int(a.horizonte if a.horizonte is not None else a.base - 150)
rng = np.random.default_rng(11)

def blur(arr, r):
    return np.asarray(Image.fromarray(np.clip(arr, 0, 255).astype(np.uint8)).filter(ImageFilter.GaussianBlur(r))).astype(float)

# ---------- 1) recorte del producto ----------
foto = np.asarray(Image.open(a.foto).convert("RGB")).astype(float)
fh, fw, _ = foto.shape
casi_blanco = (foto.min(axis=2) > 236) & ((foto.max(axis=2) - foto.min(axis=2)) < 14)
fondo = np.zeros((fh, fw), bool)
fondo[0, :] = casi_blanco[0, :]; fondo[-1, :] = casi_blanco[-1, :]
fondo[:, 0] = casi_blanco[:, 0]; fondo[:, -1] = casi_blanco[:, -1]
while True:
    d = fondo.copy()
    d[1:] |= fondo[:-1]; d[:-1] |= fondo[1:]; d[:, 1:] |= fondo[:, :-1]; d[:, :-1] |= fondo[:, 1:]
    d &= casi_blanco
    if (d == fondo).all():
        break
    fondo = d
prod = ~fondo
# quitar motas sueltas: abrir con un filtro de mínimo/máximo
pm = Image.fromarray((prod * 255).astype(np.uint8)).filter(ImageFilter.MinFilter(3)).filter(ImageFilter.MaxFilter(3))
prod = np.asarray(pm) > 127
if a.cortar_abajo:
    prod[a.cortar_abajo:] = False
ys, xs = np.where(prod)
y0, y1, x0, x1 = ys.min(), ys.max() + 1, xs.min(), xs.max() + 1
rec = foto[y0:y1, x0:x1]
alfa = np.asarray(Image.fromarray((prod[y0:y1, x0:x1] * 255).astype(np.uint8)).filter(ImageFilter.GaussianBlur(0.8))).astype(float) / 255
esc = a.alto / rec.shape[0]
if rec.shape[1] * esc > a.max_ancho:
    esc = a.max_ancho / rec.shape[1]
nw, nh = int(round(rec.shape[1] * esc)), int(round(rec.shape[0] * esc))
rec = np.asarray(Image.fromarray(rec.astype(np.uint8)).resize((nw, nh), Image.LANCZOS)).astype(float)
alfa = np.asarray(Image.fromarray((alfa * 255).astype(np.uint8)).resize((nw, nh), Image.LANCZOS)).astype(float) / 255
if esc > 1.05:   # al ampliar, un poco de nitidez
    rec = np.asarray(Image.fromarray(rec.astype(np.uint8)).filter(ImageFilter.UnsharpMask(2, 60, 2))).astype(float)

# ---------- 2) estudio cálido: pared y suelo lisos (como la foto de estudio de ESI) ----------
Y, X = np.mgrid[0:H, 0:W].astype(float)
t = np.clip(Y / max(hz, 1), 0, 1)[..., None]
pared = np.array([250, 245, 240.0]) * (1 - t) + np.array([240, 232, 225.0]) * t
curva = np.clip(1 - (hz - Y) / 320.0, 0, 1)[..., None] * (Y < hz)[..., None]   # oscurece al acercarse al suelo
pared = pared * (1 - 0.075 * curva ** 1.6)
luz = np.exp(-(((X - W * 0.5) / 560) ** 2 + ((Y - H * 0.24) / 600) ** 2))[..., None]
pared = pared + luz * np.array([5, 5, 4.0])
alto_suelo = H - hz
ts = np.linspace(0, 1, alto_suelo)[:, None, None]
suelo = np.array([245, 238, 232.0]) * (1 - ts) + np.array([249, 244, 240.0]) * ts
suelo = np.repeat(suelo, W, axis=1)
lienzo = pared.copy()
lienzo[hz:] = suelo
for i in range(-8, 12):           # transición suave pared-suelo
    y = hz + i
    if 0 <= y < H:
        k = np.clip((i + 8) / 20, 0, 1)
        lienzo[y] = pared[min(y, hz - 1)] * (1 - k) + lienzo[y] * k

# ---------- 4) hojas desenfocadas de la serie ----------
hoj = np.asarray(Image.open(AQUI / "recursos" / "hojas.png").convert("RGB")).astype(float)
def pega_hojas(region, dx, dy, flip=False, escala=1.0):
    x0r, y0r, x1r, y1r = region
    c = hoj[y0r:y1r, x0r:x1r]
    if flip: c = c[:, ::-1]
    im = Image.fromarray(c.astype(np.uint8))
    if escala != 1.0: im = im.resize((int(im.width * escala), int(im.height * escala)), Image.LANCZOS)
    c = np.asarray(im).astype(float)
    bg = np.percentile(c.reshape(-1, 3), 97, axis=0)
    f = np.clip(c / bg, 0, 1)
    hh, ww = f.shape[:2]
    ex = np.clip((ww - np.arange(ww)) / 50, 0, 1) if dx <= 0 else np.clip(np.arange(ww) / 50, 0, 1)
    ey = np.clip(np.minimum(np.arange(hh), hh - np.arange(hh)) / 50, 0, 1)
    if dy <= 0: ey = np.clip((hh - np.arange(hh)) / 50, 0, 1)
    f = 1 - (1 - f) * (ey[:, None] * ex[None, :])[..., None]
    gx0, gy0, gx1, gy1 = max(0, dx), max(0, dy), min(W, dx + ww), min(H, dy + hh)
    lienzo[gy0:gy1, gx0:gx1] *= f[gy0 - dy:gy1 - dy, gx0 - dx:gx1 - dx]
pega_hojas((0, 0, 230, 330), 0, 0, escala=1.15)
pega_hojas((0, 440, 135, 660), 0, int(H * 0.33), escala=1.1)
pega_hojas((0, 0, 230, 330), W - 210, int(H * 0.16), flip=True, escala=0.9)

# ---------- 5) sombra de contacto y producto ----------
px0 = int(round(a.cx - nw / 2)); py0 = int(round(a.base - nh))
som = np.zeros((H, W))
cy = a.base - 4
som += np.exp(-(((X - a.cx) / (nw * 0.55)) ** 2 + ((Y - cy) / 14) ** 2)) * 0.45
som += np.exp(-(((X - a.cx) / (nw * 0.75)) ** 2 + ((Y - cy - 6) / 34) ** 2)) * 0.18
lienzo = lienzo * (1 - som[..., None] * 0.55)
gx0, gy0 = max(0, px0), max(0, py0)
gx1, gy1 = min(W, px0 + nw), min(H, py0 + nh)
sub_a = alfa[gy0 - py0:gy1 - py0, gx0 - px0:gx1 - px0][..., None]
sub_p = rec[gy0 - py0:gy1 - py0, gx0 - px0:gx1 - px0]
# integrar el blanco del producto con la luz cálida de la escena
sub_p = sub_p * np.array([1.0, 0.985, 0.965])
lienzo[gy0:gy1, gx0:gx1] = lienzo[gy0:gy1, gx0:gx1] * (1 - sub_a) + sub_p * sub_a

lienzo += rng.normal(0, 1.0, (H, W, 1))
Image.fromarray(np.clip(lienzo, 0, 255).astype(np.uint8)).save(a.salida)
print("ok", a.salida, "producto", nw, "x", nh, "en", px0, py0)
