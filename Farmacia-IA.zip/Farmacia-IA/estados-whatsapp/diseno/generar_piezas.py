"""Genera las 3 piezas (1080x1920) de un producto a partir de una ficha JSON, siguiendo el patrón de la carpeta.
uso: generar_piezas.py ficha.json [--solo-html] [--archivar]
  - crea diseno/<carpeta>/ con escena, HTML y PNG de cada pieza
  - --archivar: copia a "Pendientes o sin confirmacion" de la carpeta de archivo, añade Indice.csv y guarda el embudo en embudos/
Configuración (nombre de la farmacia, carpeta de archivo): ../../config/farmacia.json
Patrones: "ortopedia" (serie Farmalastic) y "cosmetica" (serie ArticuActiv / Interapothek / ESI).
"""
import hashlib, html, json, shutil, subprocess, sys
from pathlib import Path

AQUI = Path(__file__).resolve().parent
sys.path.insert(0, str(AQUI.parent))
import comun  # noqa: E402
CFG = comun.config()
EDGE = str(comun.carpeta_edge())
ARCH = CFG["carpeta_archivo"]
EMBUDOS = AQUI.parent / "embudos"
FUENTES = ('<link href="https://fonts.googleapis.com/css2?family=Source+Serif+4:opsz,wght@8..60,400;8..60,600;8..60,700;8..60,800'
           '&family=Source+Sans+3:wght@400;600;700&family=Montserrat:wght@400;500&family=Satisfy&display=block" rel="stylesheet">')

# ---------------- iconos (trazo, viewBox 64) ----------------
I = {
 "hoja": '<path d="M10 50 C 6 24, 26 8, 54 8 C 56 34, 40 54, 14 52 Z"/><path d="M10 54 L 38 26"/>',
 "farmaceutico": '<circle cx="32" cy="19" r="10"/><path d="M12 58c0-14 9-22 20-22s20 8 20 22"/><path d="M41 47h8M45 43v8"/>',
 "chat": '<path d="M32 8C17 8 6 17.5 6 30c0 6 2.7 11.4 7.2 15.3L10 56l12.5-6.2c3 1 6.2 1.5 9.5 1.5 15 0 26-9.6 26-21.6S47 8 32 8z"/><path d="M21 26h22M21 34h14"/>',
 "farmacia": '<path d="M10 22 L15 10 H49 L54 22"/><path d="M10 22 Q 14.5 28 19 22 Q 23.5 28 28 22 Q 32.5 28 37 22 Q 41.5 28 46 22 Q 50.5 28 54 22"/><path d="M14 27 V54 H50 V27"/><path d="M28.5 33 H35.5 V38 H40.5 V45 H35.5 V50 H28.5 V45 H23.5 V38 H28.5 Z"/>',
 "lista": '<rect x="15" y="8" width="34" height="48" rx="4"/><path d="M23 20h18M23 29h18M23 38h18M23 47h10"/>',
 "dialogo": '<path d="M26 12C15 12 7 19 7 28c0 4.5 2 8.5 5.4 11.4L10 48l9.4-4.6c2 .6 4.3 1 6.6 1 11 0 19-7 19-16S37 12 26 12z"/><path d="M45 26c7 2 12 7.6 12 14 0 3.6-1.6 6.8-4.2 9.2L54 56l-7.2-3.6c-1.7.5-3.5.7-5.3.7-5.4 0-10.2-2.1-13.4-5.4"/>',
 "info": '<circle cx="32" cy="32" r="24"/><path d="M32 29v17"/><circle cx="32" cy="20" r="1.5"/>',
 "gota": '<path d="M32 6C24 18 14 29 14 40a18 18 0 0 0 36 0C50 29 40 18 32 6z"/>',
 "gotas": '<path d="M22 10C17 18 11 25 11 32a11 11 0 0 0 22 0c0-7-6-14-11-22z"/><path d="M44 26c-4 6-8 11-8 16a8 8 0 0 0 16 0c0-5-4-10-8-16z"/>',
 "escudo": '<path d="M32 6 52 13v16c0 13-8.6 23.6-20 28C20.6 52.6 12 42 12 29V13z"/><path d="M23 31l7 7 12-13"/>',
 "lumbar": '<path d="M20 4c1 8 0 14-3 20s-3 14 0 20 4 12 3 16M44 4c-1 8 0 14 3 20s3 14 0 20-4 12-3 16"/><path d="M15 27c11 3 23 3 34 0v14c-11 3-23 3-34 0z"/>',
 "deporte": '<path d="M10 26v12M16 20v24M48 20v24M54 26v12"/><path d="M16 32h32"/>',
 "calor": '<path d="M26 40V12a6 6 0 0 1 12 0v28a11 11 0 1 1-12 0z"/><path d="M32 22v24"/><circle cx="32" cy="47" r="4"/>',
 "talon": '<path d="M20 6v26c0 14 6 24 18 24h8c6 0 8-4 8-8s-3-7-8-8l-14-3V6"/><path d="M24 50c6 2 12 2 18 0" />',
 "capas": '<path d="M32 10 56 22 32 34 8 22z"/><path d="M8 32l24 12 24-12"/><path d="M8 42l24 12 24-12"/>',
 "pluma": '<path d="M50 10C30 12 16 28 14 50l4-4c10 0 22-8 28-18-6 2-10 2-14 2 8-4 14-10 18-20z"/><path d="M10 56l12-12"/>',
 "reciclar": '<path d="M20 22a16 16 0 0 1 28 4"/><path d="M48 18v9h-9"/><path d="M44 42a16 16 0 0 1-28-4"/><path d="M16 46v-9h9"/>',
 "zapato": '<path d="M6 40c0-6 2-14 4-22l8 2c2 6 8 10 16 10 6 0 12 2 18 5 4 2 6 5 6 8v3H6z"/><path d="M6 46h52"/><path d="M24 30l3-4M30 31l3-4M36 32l3-4"/>',
 "calcetin": '<path d="M22 6h18v24l10 10c4 4 4 10 0 14s-10 4-14 0L22 40z"/><path d="M22 14h18"/>',
 "ojo": '<path d="M4 32s10-16 28-16 28 16 28 16-10 16-28 16S4 32 4 32z"/><circle cx="32" cy="32" r="8"/>',
 "rollon": '<rect x="22" y="22" width="20" height="36" rx="5"/><circle cx="32" cy="14" r="8"/><path d="M22 30h20"/>',
 "colageno": '<path d="M20 8c0 12 24 12 24 24S20 44 20 56"/><path d="M44 8c0 12-24 12-24 24s24 12 24 24"/><path d="M24 16h16M24 48h16M27 32h10"/>',
 "brillo": '<path d="M32 6l5 15 15 5-15 5-5 15-5-15-15-5 15-5z"/><path d="M50 42l2 6 6 2-6 2-2 6-2-6-6-2 6-2z"/>',
 "spray": '<rect x="18" y="20" width="24" height="38" rx="5"/><rect x="24" y="10" width="12" height="10" rx="2"/><path d="M36 13h6M48 8l4-2M48 14h6M48 20l4 2"/>',
 "pie": '<path d="M22 58c-6 0-8-6-7-14 1-7 4-12 4-20 0-9 4-14 10-14s9 5 9 12c0 9-5 13-5 22 0 8-4 14-11 14z"/><circle cx="44" cy="12" r="3"/><circle cx="50" cy="19" r="2.6"/><circle cx="54" cy="27" r="2.2"/>',
 "ducha": '<path d="M14 54V16a8 8 0 0 1 16 0"/><path d="M22 22h16l4 8H18z"/><path d="M24 36v4M30 36v6M36 36v4M27 46v4M33 46v4"/>',
 "reloj": '<circle cx="32" cy="32" r="24"/><path d="M32 18v14l10 6"/>',
 "cinta": '<circle cx="22" cy="27" r="15"/><circle cx="22" cy="27" r="4.5"/><path d="M22 42 H58 V34 H34"/><path d="M40 34 V38 M46 34 V40 M52 34 V38"/><path d="M58 31 V45"/>',
 "plato": '<path d="M10 34h44c0 11-9.8 18-22 18S10 45 10 34z"/><path d="M20 34c0-6 3-10 7-12M30 34c1-7 5-12 11-13M42 34c0-4 2-7 5-8"/><path d="M26 52v4h12v-4"/>',
 "corazon": '<path d="M32 54S8 40 8 23a12 12 0 0 1 24-4 12 12 0 0 1 24 4c0 17-24 31-24 31z"/>',
 "sol": '<circle cx="32" cy="32" r="11"/><path d="M32 6v8M32 50v8M6 32h8M50 32h8M13.6 13.6l5.7 5.7M44.7 44.7l5.7 5.7M13.6 50.4l5.7-5.7M44.7 19.3l5.7-5.7"/>',
 "luna": '<path d="M44 44A22 22 0 0 1 22 12a22 22 0 1 0 22 32z"/>',
 "etiqueta": '<path d="M8 32 30 10h22v22L30 54z"/><circle cx="43" cy="20" r="3.5"/>',
}
def svg(nombre, color, tam=None, grosor=3):
    w = f' width="{tam}" height="{tam}"' if tam else ''
    return (f'<svg{w} viewBox="0 0 64 64" fill="none" stroke="{color}" stroke-width="{grosor}" '
            f'stroke-linecap="round" stroke-linejoin="round">{I.get(nombre, I["info"])}</svg>')
def e(t):  # escapar texto pero permitir <br>
    return html.escape(t or "").replace("&lt;br&gt;", "<br>")

AJUSTE_JS = """<script>
document.fonts.ready.then(() => {
  document.querySelectorAll('.fit').forEach(el => {
    let s = parseFloat(getComputedStyle(el).fontSize);
    while (el.scrollWidth > el.clientWidth + 1 && s > 12) { s -= 1; el.style.fontSize = s + 'px'; }
  });
  document.querySelectorAll('.fitv').forEach(el => {
    let s = parseFloat(getComputedStyle(el).fontSize);
    while ((el.scrollHeight > el.clientHeight + 1 || el.scrollWidth > el.clientWidth + 1) && s > 12) { s -= 1; el.style.fontSize = s + 'px'; }
  });
});
</script>"""

def cabecera(color):
    return (f'<div class="abs cab"><div class="f1">{e(CFG["cabecera"][0])}</div><div class="f2">{e(CFG["cabecera"][1])}</div>'
            f'<div class="linea"><i></i><svg width="36" height="36" viewBox="0 0 34 34" fill="none" stroke="{color}" '
            f'stroke-width="2.4" stroke-linejoin="round"><path d="M12 3h10v9h9v10h-9v9H12v-9H3V12h9z"/></svg><i></i></div></div>')

def trazo(top, ancho, color, left=None, rot=0):
    pos = f"left:{left}px;" if left is not None else "left:0;width:1080px;text-align:center;"
    return (f'<div class="abs" style="top:{top}px;{pos}transform:rotate({rot}deg);"><svg width="{ancho}" height="22" viewBox="0 0 400 20" preserveAspectRatio="none">'
            f'<path d="M2 17 C 110 2, 280 0, 398 9 C 280 5, 110 8, 2 17 Z" fill="{color}"/></svg></div>')

CSS_BASE = """
* { margin:0; padding:0; box-sizing:border-box; }
html, body { width:1080px; height:1920px; overflow:hidden; background:#f6efec; }
.lienzo { position:relative; width:1080px; height:1920px; background:url("FONDO") no-repeat 0 0/1080px 1920px; font-family:"Source Sans 3",sans-serif; color:var(--p); }
.abs { position:absolute; }
.c { left:0; width:1080px; text-align:center; }
.cab { top:44px; left:0; width:1080px; text-align:center; font-family:"Montserrat",sans-serif; color:#262626; }
.cab .f1 { font-size:26px; letter-spacing:7px; font-weight:500; padding-left:7px; }
.cab .f2 { font-size:44px; letter-spacing:5.5px; margin-top:2px; padding-left:5px; }
.cab .linea { display:flex; align-items:center; justify-content:center; gap:20px; margin-top:8px; }
.cab .linea i { display:block; width:124px; height:2px; background:var(--p); }
.serif { font-family:"Source Serif 4",serif; }
.fit { white-space:nowrap; overflow:hidden; }
.manus { font-family:"Satisfy",cursive; line-height:1.05; color:var(--p); }
.circ { flex:none; border-radius:50%; border:3px solid var(--p); display:flex; align-items:center; justify-content:center; }
.sep { flex:none; width:2px; background:var(--p); opacity:.5; }
"""

# =============================== ORTOPEDIA ===============================
CSS_ORTO = CSS_BASE + """
.tit { font-family:"Source Serif 4",serif; font-weight:700; line-height:1.02; letter-spacing:-1.5px; font-variation-settings:"opsz" 60; width:1000px; left:40px; text-align:center; }
.marca { font-family:"Source Serif 4",serif; font-weight:700; font-size:64px; line-height:1; width:1000px; left:40px; text-align:center; }
.modelo { font-family:"Source Serif 4",serif; font-size:40px; line-height:1.05; width:1000px; left:40px; text-align:center; }
.extra { font-size:32px; width:1000px; left:40px; text-align:center; color:var(--p); }
.tarjeta { position:absolute; background:var(--t); border:2px solid var(--tb); border-radius:30px; box-shadow:0 10px 28px rgba(0,0,0,.07); display:flex; align-items:center; }
.tarjeta h3 { font-family:"Source Serif 4",serif; font-weight:700; color:var(--p); line-height:1.05; }
.tarjeta p { color:#3b2a31; line-height:1.2; }
.pastilla { background:var(--p); color:#fff; font-weight:700; font-size:23px; letter-spacing:3px; padding:6px 18px 5px; border-radius:999px; }
.aviso { font-size:22px; color:#2e2629; }
.pie { left:0; top:1830px; width:1080px; height:90px; background:var(--pie); color:#fff; font-family:"Montserrat",sans-serif; display:flex; flex-direction:column; align-items:center; justify-content:center; }
.pie .n { font-size:25px; letter-spacing:7px; font-weight:500; padding:0 0 8px 7px; border-bottom:1.5px solid rgba(255,255,255,.75); }
.pie .l { font-size:15px; letter-spacing:5px; margin-top:8px; padding-left:5px; }
"""

def orto_comun(f, pz, titulo_top, tit_size):
    p = f["colores"]["principal"]
    lineas = pz["titulo"] if isinstance(pz["titulo"], list) else [pz["titulo"]]
    h = cabecera(p)
    y = titulo_top
    for ln in lineas:
        h += f'<div class="abs tit fit" style="top:{y}px;font-size:{tit_size}px;">{e(ln)}</div>'
        y += int(tit_size * 1.04)
    h += trazo(y + 8, 440, p)
    y += 34
    h += f'<div class="abs marca fit" style="top:{y}px;">{e(f["marca"])}</div>'
    y += 74
    h += f'<div class="abs modelo fit" style="top:{y}px;">{e(pz.get("modelo", f.get("modelo", "")))}</div>'
    y += 48
    if pz.get("extra"):
        h += f'<div class="abs extra fit" style="top:{y}px;">{e(pz["extra"])}</div>'
    return h

def orto_cierre(f, pz, top1, s1=84, s2=48):
    h = f'<div class="abs c manus fit" style="top:{top1}px;font-size:{s1}px;">{e(pz["cierre"][0])}</div>'
    h += f'<div class="abs c manus fit" style="top:{top1 + int(s1 * 1.15)}px;font-size:{s2}px;">{e(pz["cierre"][1])}</div>'
    h += f'<div class="abs c aviso" style="top:1792px;">{e(f["aviso"])}</div>'
    h += f'<div class="abs pie"><div class="n">{e(CFG["firma"])}</div><div class="l">{e(CFG["lema"])}</div></div>'
    return h

def orto_p1(f, pz):
    p = f["colores"]["principal"]
    h = orto_comun(f, pz, 190, 100)
    b = pz["beneficio"]
    h += (f'<div class="tarjeta" style="left:70px;top:1338px;width:940px;height:190px;padding:0 40px;">'
          f'<div class="circ" style="width:126px;height:126px;">{svg(b["icono"], p, 76, 2.6)}</div>'
          f'<div class="sep" style="height:110px;margin:0 32px;"></div>'
          f'<h3 class="fitv" style="font-size:42px;width:660px;height:150px;display:flex;align-items:center;">{e(b["texto"])}</h3></div>')
    h += orto_cierre(f, pz, 1556)
    return h

def orto_p2(f, pz):
    p = f["colores"]["principal"]
    h = orto_comun(f, pz, 196, 100)
    x = 50
    for c in pz["tarjetas"][:2]:
        h += (f'<div class="tarjeta" style="left:{x}px;top:1168px;width:474px;height:218px;padding:0 22px;">'
              f'<div class="circ" style="width:112px;height:112px;">{svg(c["icono"], p, 66, 2.6)}</div>'
              f'<div class="sep" style="height:120px;margin:0 20px;"></div>'
              f'<div style="width:280px;"><h3 class="fit" style="font-size:34px;width:280px;">{e(c["titulo"])}</h3>'
              f'<p style="font-size:25px;margin-top:8px;">{e(c["texto"])}</p></div></div>')
        x += 506
    i = pz["info"]
    h += (f'<div class="tarjeta" style="left:120px;top:1410px;width:840px;height:124px;padding:0 34px;background:var(--t2);">'
          f'<div class="circ" style="width:84px;height:84px;border-width:2.5px;">{svg(i["icono"], p, 50, 3)}</div>'
          f'<div class="sep" style="height:66px;margin:0 26px;"></div>'
          f'<h3 class="fitv" style="font-size:33px;width:640px;height:100px;display:flex;align-items:center;">{e(i["texto"])}</h3></div>')
    h += orto_cierre(f, pz, 1560, 80, 46)
    return h

def orto_p3(f, pz):
    p = f["colores"]["principal"]
    h = orto_comun(f, pz, 214, 108)
    k = pz["clave"]
    h += (f'<div class="tarjeta" style="left:54px;top:1282px;width:972px;height:200px;padding:0 36px;">'
          f'<div class="circ" style="width:132px;height:132px;">{svg(k["icono"], p, 90, 2.6)}</div>'
          f'<div class="sep" style="height:124px;margin:0 32px;"></div>'
          f'<div style="display:flex;flex-direction:column;align-items:flex-start;width:700px;">'
          f'<span class="pastilla">{e(k["pastilla"])}</span>'
          f'<span class="serif fit" style="font-weight:700;font-size:74px;line-height:1.05;margin-top:8px;width:700px;">{e(k["grande"])}</span>'
          f'<span class="fit" style="font-size:30px;color:#3b2a31;width:700px;">{e(k["detalle"])}</span></div></div>')
    o = pz["orienta"]
    h += (f'<div class="tarjeta" style="left:120px;top:1506px;width:840px;height:110px;padding:0 32px;background:var(--t2);">'
          f'<div class="circ" style="width:80px;height:80px;border-width:2.5px;">{svg(o["icono"], p, 48, 3)}</div>'
          f'<div class="sep" style="height:64px;margin:0 26px;"></div>'
          f'<p class="serif fitv" style="font-weight:600;font-size:34px;line-height:1.12;color:var(--p);width:660px;height:84px;display:flex;align-items:center;">{e(o["texto"])}</p></div>')
    h += orto_cierre(f, pz, 1630)
    return h

# =============================== COSMÉTICA / COMPLEMENTOS ===============================
CSS_COSM = CSS_BASE + """
.etiqueta { top:186px; right:30px; height:62px; padding:0 28px 0 22px; background:var(--p); color:#fff; border-radius:999px; display:flex; align-items:center; gap:13px; font-weight:700; font-size:24px; letter-spacing:.5px; box-shadow:0 6px 16px rgba(0,0,0,.15); }
.t { font-family:"Source Serif 4",serif; font-weight:800; line-height:1; letter-spacing:-2px; font-variation-settings:"opsz" 60; left:40px; width:1000px; text-align:center; }
.sub { font-size:34px; color:#2b2e38; left:40px; width:1000px; text-align:center; }
.panel { background:var(--t); border:1.5px solid var(--tb); border-radius:28px; box-shadow:0 10px 30px rgba(0,0,0,.06); }
.fila { display:flex; align-items:center; gap:18px; padding:0 14px 0 18px; }
.fila + .fila { border-top:2px dotted var(--sep); }
.fila .circ { width:92px; height:92px; border-width:2.5px; }
.fila h3 { font-size:29px; font-weight:700; color:var(--p); line-height:1.05; }
.fila p { font-size:25px; color:#2b2e38; line-height:1.2; margin-top:6px; }
.dispo { background:var(--p); color:#fff; border-radius:24px; display:flex; align-items:center; justify-content:center; gap:24px; box-shadow:0 10px 24px rgba(0,0,0,.18); }
.banda { left:0; width:1080px; background:rgba(255,252,249,.93); display:flex; align-items:center; }
.banda > div { flex:1; display:flex; flex-direction:column; align-items:center; gap:10px; }
.banda > div + div { border-left:2px solid var(--sep); }
.banda .circ { width:86px; height:86px; border-width:2.5px; }
.banda span { font-size:26px; color:#2b2e38; text-align:center; line-height:1.12; }
.pie { left:0; width:1080px; background:var(--pie); display:flex; align-items:center; justify-content:space-between; padding:0 40px 0 36px; color:#fff; }
.pie .aviso { font-family:"Satisfy",cursive; font-size:27px; line-height:1.3; white-space:nowrap; }
.pie .firma { text-align:center; font-family:"Montserrat",sans-serif; white-space:nowrap; }
.pie .firma .n { font-size:19px; letter-spacing:3.8px; font-weight:500; padding-bottom:10px; border-bottom:1.5px solid rgba(255,255,255,.7); }
.pie .firma .l { font-size:13.5px; letter-spacing:2.8px; margin-top:10px; }
.paso { display:flex; align-items:center; gap:18px; padding:0 16px 0 0; position:relative; }
.paso .num { position:absolute; left:-16px; top:4px; width:52px; height:52px; border-radius:50%; background:var(--p); color:#fff; font-family:"Source Serif 4",serif; font-weight:700; font-size:32px; display:flex; align-items:center; justify-content:center; }
.paso .circ { margin-left:28px; width:94px; height:94px; border-width:2.5px; }
.paso h3 { font-family:"Source Serif 4",serif; font-weight:700; font-size:31px; color:var(--p); line-height:1.08; }
.paso p { font-size:25px; color:#2b2e38; line-height:1.18; margin-top:4px; }
"""

def cosm_etiqueta(pz):
    et = pz["etiqueta"]
    return f'<div class="abs etiqueta">{svg(et.get("icono", "hoja"), "#fff", 34, 3.5)}{e(et["texto"])}</div>'

def cosm_filas(f, filas, top, alto):
    p = f["colores"]["principal"]
    h = f'<div class="abs panel" style="left:637px;top:{top}px;width:413px;height:{alto}px;display:flex;flex-direction:column;">'
    for c in filas:
        h += (f'<div class="fila" style="flex:1;"><div class="circ">{svg(c["icono"], p, 56, 3)}</div>'
              f'<div style="width:270px;"><h3 class="fit" style="width:270px;">{e(c["titulo"])}</h3><p>{e(c["texto"])}</p></div></div>')
    return h + '</div>'

def cosm_dispo(pz):
    t = pz.get("recuadro", "Consulta precio<br>y disponibilidad")
    return (f'<div class="abs dispo" style="left:637px;top:1200px;width:413px;height:130px;">{svg("chat", "#fff", 58, 3)}'
            f'<div style="font-weight:700;font-size:33px;line-height:1.12;">{e(t)}</div></div>')

def cosm_manus_derecha(f, pz, top=1356, size=41):
    p = f["colores"]["principal"]
    return (f'<div class="abs manus fitv" style="left:612px;top:{top}px;width:450px;height:112px;text-align:center;font-size:{size}px;transform:rotate(-4deg);">{e(pz["manus2"])}</div>'
            + trazo(top + 108, 280, p, left=716, rot=-4))

def cosm_banda(f, pz):
    p = f["colores"]["principal"]
    h = '<div class="abs banda" style="top:1530px;height:210px;">'
    for b in pz["banda"][:3]:
        h += f'<div><div class="circ">{svg(b["icono"], p, 50, 3)}</div><span>{e(b["texto"])}</span></div>'
    return h + '</div>'

def cosm_pie(f, top=1740, alto=180):
    return (f'<div class="abs pie" style="top:{top}px;height:{alto}px;"><div class="aviso">{e(f["aviso_pie"])}</div>'
            f'<div class="firma"><div class="n">{e(CFG["firma"])}</div><div class="l">{e(CFG["lema"])}</div></div></div>')

def cosm_p1(f, pz):
    c = f["colores"]
    h = cabecera(c["principal"]) + cosm_etiqueta(pz)
    h += f'<div class="abs t fit" style="top:262px;font-size:118px;color:{c["principal"]};">{e(pz["t1"])}</div>'
    h += f'<div class="abs t fit" style="top:384px;font-size:80px;letter-spacing:-1.5px;color:{c["acento"]};">{e(pz["t2"])}</div>'
    h += f'<div class="abs sub fit" style="top:478px;">{e(pz["sub"])}</div>'
    h += f'<div class="abs c manus fit" style="top:535px;font-size:68px;">{e(pz["manus"])}</div>' + trazo(612, 464, c["principal"])
    h += cosm_filas(f, pz["filas"], 680, 500) + cosm_dispo(pz) + cosm_manus_derecha(f, pz) + cosm_banda(f, pz) + cosm_pie(f)
    return h

def cosm_p2(f, pz):
    c = f["colores"]
    h = cabecera(c["principal"]) + cosm_etiqueta(pz)
    h += f'<div class="abs t fit" style="top:262px;font-size:106px;color:{c["principal"]};">{e(pz["t1"])}</div>'
    h += f'<div class="abs t fit" style="top:372px;font-size:106px;color:{c["acento"]};">{e(pz["t2"])}</div>'
    r = pz["respuesta"]
    h += (f'<div class="abs panel" style="left:300px;top:506px;width:750px;height:160px;padding:14px 28px 0 34px;">'
          f'<div class="t fit" style="position:static;width:688px;text-align:left;font-size:70px;letter-spacing:-1px;color:{c["principal"]};">{e(r["grande"])}</div>'
          f'<div class="serif fit" style="font-weight:700;font-size:28px;color:{c["principal"]};margin-top:8px;width:688px;">{e(r["frase"])}</div></div>')
    h += trazo(642, 420, c["principal"], left=340)
    h += cosm_filas(f, pz["filas"], 700, 470) + cosm_dispo(pz) + cosm_manus_derecha(f, pz) + cosm_banda(f, pz) + cosm_pie(f)
    return h

def cosm_p3(f, pz):
    c = f["colores"]
    p = c["principal"]
    h = cabecera(p) + cosm_etiqueta(pz)
    h += f'<div class="abs t fit" style="top:262px;font-size:118px;color:{p};">{e(pz["t1"])}</div>'
    h += f'<div class="abs t fit" style="top:384px;font-size:118px;color:{c["acento"]};">{e(pz["t2"])}</div>'
    h += trazo(522, 590, p)
    fi = pz["ficha"]
    h += (f'<div class="abs panel" style="left:214px;top:566px;width:652px;height:150px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:8px;">'
          f'<div style="display:flex;align-items:center;gap:22px;">'
          f'<div style="background:{c.get("insignia", p)};color:#fff;font-weight:700;font-size:34px;padding:2px 18px;border-radius:999px;border:3px solid #fff;box-shadow:0 0 0 2px {c.get("insignia", p)};">{e(fi["insignia"])}</div>'
          f'<div style="width:2px;height:52px;background:var(--sep);"></div>'
          f'<div class="fit" style="font-weight:700;font-size:50px;color:{p};line-height:1;max-width:440px;">{e(fi["nombre"])}</div></div>'
          f'<div class="fit" style="font-size:26px;color:#2b2e38;max-width:610px;">{e(fi["sub"])} <b style="color:{c["acento"]};">{e(fi.get("destacado", ""))}</b></div></div>')
    h += '<div class="abs" style="left:637px;top:790px;width:413px;display:flex;flex-direction:column;gap:18px;">'
    for n, s in enumerate(pz["pasos"][:3], 1):
        h += (f'<div class="panel" style="height:190px;display:flex;align-items:center;"><div class="paso"><div class="num">{n}</div>'
              f'<div class="circ">{svg(s["icono"], p, 56, 3)}</div><div style="width:250px;"><h3>{e(s["titulo"])}</h3><p>{e(s["texto"])}</p></div></div></div>')
    h += '</div>'
    h += (f'<div class="abs manus fitv" style="left:572px;top:1446px;width:500px;height:150px;text-align:center;font-size:64px;transform:rotate(-4deg);">{e(pz["manus2"])}</div>'
          + trazo(1612, 330, p, left=672, rot=-4))
    h += cosm_pie(f)
    return h

PATRONES = {
    "ortopedia": (CSS_ORTO, {"presentacion": orto_p1, "consideracion": orto_p2, "conversion": orto_p3}),
    "cosmetica": (CSS_COSM, {"presentacion": cosm_p1, "consideracion": cosm_p2, "conversion": cosm_p3}),
}

def pagina(f, pz, fondo):
    css, fn = PATRONES[f["patron"]]
    c = f["colores"]
    vars_ = (f':root{{--p:{c["principal"]};--pie:{c.get("pie", c["principal"])};--t:{c.get("tarjeta", "rgba(255,247,242,.92)")};'
             f'--t2:{c.get("tarjeta2", c.get("tarjeta", "rgba(255,250,248,.93)"))};--tb:{c.get("borde", "rgba(0,0,0,.12)")};--sep:{c.get("separador", "rgba(0,0,0,.22)")};}}')
    cuerpo = fn[pz["fase"]](f, pz)
    return (f'<!doctype html><html lang="es"><head><meta charset="utf-8"><title>{e(f["nombre_archivo"])} {pz["fase"]}</title>{FUENTES}'
            f'<style>{vars_}{css.replace("FONDO", fondo)}</style></head><body><div class="lienzo">{cuerpo}</div>{AJUSTE_JS}</body></html>')

def ruta_foto(p):
    """Las fotos de las fichas pueden ir con ruta relativa a esta carpeta (fotos/<codigo>.jpg)."""
    p = Path(p)
    return p if p.is_absolute() else AQUI / p

def render(html_path, png_path):
    if png_path.exists(): png_path.unlink()
    subprocess.run([EDGE, "--headless=new", "--disable-gpu", "--hide-scrollbars", "--force-device-scale-factor=1",
                    "--window-size=1080,1920", "--virtual-time-budget=12000", f"--screenshot={png_path}",
                    "file:///" + str(html_path).replace("\\", "/")], capture_output=True, timeout=120)
    if not png_path.exists():
        raise SystemExit(f"No se generó {png_path}")

def main():
    ficha = Path(sys.argv[1]).resolve()
    f = json.loads(ficha.read_text(encoding="utf-8"))
    carpeta = AQUI / f["carpeta"]
    carpeta.mkdir(parents=True, exist_ok=True)
    for pz in f["piezas"]:
        esc = {**f.get("escena", {}), **pz.get("escena", {})}
        fondo = carpeta / f'fondo_{pz["fase"]}.png'
        if "--solo-html" not in sys.argv or not fondo.exists():
            cmd = [sys.executable, "-I", str(AQUI / "escena_packshot.py"), str(ruta_foto(f["foto"])), str(fondo),
                   "--alto", str(esc["alto"]), "--cx", str(esc["cx"]), "--base", str(esc["base"])]
            if esc.get("horizonte"): cmd += ["--horizonte", str(esc["horizonte"])]
            if esc.get("max_ancho"): cmd += ["--max-ancho", str(esc["max_ancho"])]
            if f.get("cortar_abajo"): cmd += ["--cortar-abajo", str(f["cortar_abajo"])]
            subprocess.run(cmd, check=True, capture_output=True)
        hp = carpeta / f'{pz["fase"]}.html'
        hp.write_text(pagina(f, pz, fondo.name), encoding="utf-8")
        render(hp, carpeta / f'{pz["fase"]}.png')
        print("ok", pz["fase"])
    if "--archivar" in sys.argv:
        archivar(f, carpeta)

def archivar(f, carpeta):
    nombre = f["nombre_archivo"]
    destino = ARCH / "Pendientes o sin confirmacion" / nombre
    destino.mkdir(parents=True, exist_ok=True)
    idx = ARCH / "Indice.csv"
    # bytes, no read_text/write_text: en Windows convierten los saltos de línea y salían filas en blanco (23/11/2026)
    previo = idx.read_bytes().decode("utf-8-sig") if idx.exists() else "fecha;producto;estado;archivo;origen;sha256"
    txt = "\r\n".join(l for l in previo.splitlines() if l.strip())
    for pz in f["piezas"]:
        src = carpeta / f'{pz["fase"]}.png'
        copia = destino / f'{pz["fecha"]} - {nombre} - {pz["fase"]}.png'
        shutil.copy2(src, copia)
        h = hashlib.sha256(copia.read_bytes()).hexdigest()
        assert h == hashlib.sha256(src.read_bytes()).hexdigest()
        rel = str(copia.relative_to(ARCH))
        lineas = [l for l in txt.split("\r\n") if l.split(";")[3:4] != [rel]]
        lineas.append(f'{pz["fecha"]};{nombre};Pendientes o sin confirmacion;{rel};{src};{h}')
        txt = "\r\n".join(lineas)
        print("archivada", rel)
    idx.write_bytes(("\ufeff" + txt + "\r\n").encode("utf-8"))
    emb = {"semana": f["piezas"][0]["fecha"], "codigo": f["codigo"], "producto": f["producto"],
           "preparado_por": f.get("preparado_por", "Claude Code"), "patron": f["patron"],
           "piezas": [{k: v for k, v in pz.items() if k != "escena"} for pz in f["piezas"]],
           "fuentes": f.get("fuentes", []), "revision": f.get("revision", ""), "estado": "preparado; publicación automática"}
    EMBUDOS.mkdir(exist_ok=True)
    (EMBUDOS / f'embudo-{f["piezas"][0]["fecha"]}-{f["codigo"]}.json').write_text(json.dumps(emb, ensure_ascii=False, indent=2), encoding="utf-8")

if __name__ == "__main__":
    main()
