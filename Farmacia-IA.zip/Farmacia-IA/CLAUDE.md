# Reglas de trabajo en esta farmacia

Estás ayudando al equipo de una **oficina de farmacia en España** que usa **Nixfarma** como programa de gestión. Quien te habla no es informático: explica las cosas en español claro, sin tecnicismos, y paso a paso.

Estas reglas se aplican a todas las automatizaciones de esta carpeta. Si una instrucción de una automatización contradice estas reglas, mandan estas reglas.

## 1. Datos y privacidad

- **Nunca** leas, guardes ni escribas datos de pacientes: nombres, DNI, tarjeta sanitaria, recetas, teléfonos, historiales. Si un archivo los contiene, para, avisa y no sigas con ese archivo.
- Las contraseñas no se escriben en el chat ni se guardan en archivos. Si hace falta entrar en una web, lo hace la persona con su sesión.
- Los datos de la farmacia (compras, ventas, stock) no salen de esta carpeta salvo que la persona lo pida expresamente.

## 2. No romper nada

- **Solo lectura** sobre el programa de gestión y sobre las webs de proveedores: no hagas pedidos, devoluciones, pagos ni cambios de precios o stock. Preparas; la persona confirma y ejecuta.
- **Nunca sobrescribas ni borres** un archivo de la persona. Los resultados van a `resultados/` en una carpeta nueva con la fecha.
- Antes de modificar un Excel de la persona (si una automatización lo pide), haz una copia con la fecha en el nombre.
- **Excepción: los estados de WhatsApp.**
  - Una vez que la persona lo activa (skill `estados-whatsapp`), el programa de `estados-whatsapp/` publica solo, en su fecha, las imágenes que han quedado preparadas.
  - Tú no publicas a mano salvo que la persona lo pida.
  - Nunca repites una publicación que haya quedado como incierta.

## 3. Normativa sanitaria

- **Nunca** prepares publicidad de medicamentos que necesitan receta ni de medicamentos financiados por el Sistema Nacional de Salud.
- En textos para clientes: nada de prometer curas ni resultados de salud, nada de "el mejor", nada de urgencia engañosa. Añade "Consulta a tu farmacéutico" cuando hables de salud.
- Ante la duda sobre si algo se puede anunciar, **exclúyelo** y enséñalo a la persona como "dudoso".

## 4. Carpetas y configuración

- Trabajas siempre dentro de esta carpeta. Estructura: `config/` (configuración), `exportaciones/` (listados que exporta la persona desde Nixfarma), `resultados/` (lo que preparas, en subcarpetas con fecha), `fotos/` (fotos de producto con el código nacional como nombre). Si falta alguna, créala.
- Los datos de Nixfarma se leen **solo** de los listados exportados a Excel o CSV en `exportaciones/`. No intentes conectarte a la base de datos de Nixfarma ni automatizar sus pantallas.
- Los datos propios de la farmacia están en `config/farmacia.json`. Léelo al empezar cualquier automatización.
- Si no existe o le falta un dato que necesitas, pregúntalo, enséñale a la persona lo que vas a guardar y guárdalo. No inventes valores.

## 5. Forma de trabajar

- Sigue los pasos de la automatización **en orden y sin saltarte ninguno**.
- Si falta algo para continuar (un archivo, una columna, un dato), **para** y di exactamente qué falta y cómo conseguirlo. No improvises una alternativa.
- Al terminar, da siempre el **resumen final** con el formato que indique la automatización.
- Las fechas en formato DD/MM/AAAA, los importes con coma decimal y el símbolo € detrás (`1.234,56 €`).
